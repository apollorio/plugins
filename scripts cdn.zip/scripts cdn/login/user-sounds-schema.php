<?php
/**
 * Apollo User Sounds Database Schema
 *
 * Creates and manages the user_sounds table for storing
 * user music genre preferences for matchmaking.
 *
 * @package Apollo_Core
 * @since 3.2.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Create user sounds table.
 *
 * @return void
 */
function apollo_create_user_sounds_table() {
	global $wpdb;

	$table_name      = $wpdb->prefix . 'apollo_user_sounds';
	$charset_collate = $wpdb->get_charset_collate();

	$sql = "CREATE TABLE IF NOT EXISTS $table_name (
		id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
		user_id bigint(20) unsigned NOT NULL,
		sound_slug varchar(50) NOT NULL,
		priority tinyint(2) unsigned DEFAULT 0,
		created_at datetime DEFAULT CURRENT_TIMESTAMP,
		PRIMARY KEY (id),
		UNIQUE KEY user_sound_unique (user_id, sound_slug),
		KEY user_id_idx (user_id),
		KEY sound_slug_idx (sound_slug)
	) $charset_collate;";

	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	dbDelta( $sql );

	update_option( 'apollo_user_sounds_db_version', '1.0.0' );
}

/**
 * Get available sounds/genres list.
 *
 * Syncs with event_sounds taxonomy from post-types.php
 *
 * @return array Sound slug => label.
 */
function apollo_get_available_sounds() {
	$default_sounds = array(
		'techno'      => __( 'Techno', 'apollo-core' ),
		'house'       => __( 'House', 'apollo-core' ),
		'trance'      => __( 'Trance', 'apollo-core' ),
		'drum_bass'   => __( 'Drum & Bass', 'apollo-core' ),
		'funk'        => __( 'Funk', 'apollo-core' ),
		'tribal'      => __( 'Tribal', 'apollo-core' ),
		'minimal'     => __( 'Minimal', 'apollo-core' ),
		'progressive' => __( 'Progressive', 'apollo-core' ),
		'melodic'     => __( 'Melodico', 'apollo-core' ),
		'hard'        => __( 'Hard', 'apollo-core' ),
		'psy'         => __( 'Psy', 'apollo-core' ),
		'ambient'     => __( 'Ambient', 'apollo-core' ),
	);

	// Try to get from event_sounds taxonomy if it exists
	if ( taxonomy_exists( 'event_sounds' ) ) {
		$terms = get_terms( array(
			'taxonomy'   => 'event_sounds',
			'hide_empty' => false,
		) );

		if ( ! is_wp_error( $terms ) && ! empty( $terms ) ) {
			$sounds = array();
			foreach ( $terms as $term ) {
				$sounds[ $term->slug ] = $term->name;
			}
			return apply_filters( 'apollo_available_sounds', $sounds );
		}
	}

	return apply_filters( 'apollo_available_sounds', $default_sounds );
}

/**
 * Check if sounds table exists.
 *
 * @return bool True if table exists.
 */
function apollo_user_sounds_table_exists() {
	global $wpdb;

	$table_name = $wpdb->prefix . 'apollo_user_sounds';

	$result = $wpdb->get_var(
		$wpdb->prepare( 'SHOW TABLES LIKE %s', $table_name )
	);

	return $result === $table_name;
}

/**
 * Drop user sounds table (for uninstall).
 *
 * @return void
 */
function apollo_drop_user_sounds_table() {
	global $wpdb;

	$table_name = $wpdb->prefix . 'apollo_user_sounds';

	$wpdb->query( "DROP TABLE IF EXISTS $table_name" );

	delete_option( 'apollo_user_sounds_db_version' );
}
