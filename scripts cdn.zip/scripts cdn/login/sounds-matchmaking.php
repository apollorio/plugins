<?php
/**
 * Apollo Sounds Matchmaking
 *
 * Matches users with events based on sound preferences.
 * Connects to event_sounds taxonomy from post-types.php.
 *
 * @package Apollo_Core
 * @since 3.2.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Get events matching user's sound preferences.
 *
 * @param int   $user_id User ID.
 * @param array $args    Query args.
 * @return array Array of event post objects.
 */
function apollo_get_matched_events_for_user( $user_id, $args = array() ) {
	$user_sounds = apollo_get_user_sounds( $user_id );

	if ( empty( $user_sounds ) ) {
		return array();
	}

	$defaults = array(
		'post_type'      => 'event_listing',
		'post_status'    => 'publish',
		'posts_per_page' => 20,
		'orderby'        => 'meta_value',
		'order'          => 'ASC',
		'meta_key'       => '_event_date',
		'meta_query'     => array(
			array(
				'key'     => '_event_date',
				'value'   => current_time( 'Y-m-d' ),
				'compare' => '>=',
				'type'    => 'DATE',
			),
		),
		'tax_query'      => array(
			array(
				'taxonomy' => 'event_sounds',
				'field'    => 'slug',
				'terms'    => $user_sounds,
				'operator' => 'IN',
			),
		),
	);

	$query_args = wp_parse_args( $args, $defaults );

	$query = new WP_Query( $query_args );

	return $query->posts;
}

/**
 * Calculate match score between user and event.
 *
 * Score ranges from 0-100:
 * - 70% weight: How many of user's sounds match the event
 * - 30% weight: How many of event's sounds match user's preferences
 *
 * @param int $user_id  User ID.
 * @param int $event_id Event post ID.
 * @return array Match data with score.
 */
function apollo_calculate_event_match_score( $user_id, $event_id ) {
	$user_sounds  = apollo_get_user_sounds( $user_id );
	$event_sounds = wp_get_post_terms( $event_id, 'event_sounds', array( 'fields' => 'slugs' ) );

	if ( is_wp_error( $event_sounds ) ) {
		$event_sounds = array();
	}

	$matched_sounds     = array_intersect( $user_sounds, $event_sounds );
	$total_user_sounds  = count( $user_sounds );
	$total_event_sounds = count( $event_sounds );
	$matched_count      = count( $matched_sounds );

	// Calculate percentage match
	$score = 0;
	if ( $total_user_sounds > 0 && $total_event_sounds > 0 ) {
		// Weight: 70% based on user prefs, 30% based on event coverage
		$user_match  = ( $matched_count / $total_user_sounds ) * 70;
		$event_match = ( $matched_count / $total_event_sounds ) * 30;
		$score       = round( $user_match + $event_match );
	} elseif ( $total_user_sounds > 0 && $matched_count > 0 ) {
		// Event has no sounds but user does - partial match
		$score = round( ( $matched_count / $total_user_sounds ) * 50 );
	}

	return array(
		'score'          => min( 100, $score ),
		'matched_sounds' => array_values( $matched_sounds ),
		'user_sounds'    => $user_sounds,
		'event_sounds'   => $event_sounds,
		'match_count'    => $matched_count,
		'is_perfect'     => $score >= 80,
		'is_good'        => $score >= 50,
		'is_partial'     => $score >= 25 && $score < 50,
	);
}

/**
 * Get recommended events for user with match scores.
 *
 * @param int $user_id User ID.
 * @param int $limit   Max events.
 * @return array Events with match data.
 */
function apollo_get_recommended_events( $user_id, $limit = 10 ) {
	$events = apollo_get_matched_events_for_user( $user_id, array(
		'posts_per_page' => $limit * 2, // Get more to sort by score
	) );

	$recommendations = array();

	foreach ( $events as $event ) {
		$match = apollo_calculate_event_match_score( $user_id, $event->ID );

		$recommendations[] = array(
			'event_id'    => $event->ID,
			'event_title' => $event->post_title,
			'event_date'  => get_post_meta( $event->ID, '_event_date', true ),
			'event_url'   => get_permalink( $event->ID ),
			'match_data'  => $match,
		);
	}

	// Sort by score descending
	usort( $recommendations, function( $a, $b ) {
		return $b['match_data']['score'] - $a['match_data']['score'];
	} );

	return array_slice( $recommendations, 0, $limit );
}

/**
 * Find users with similar sound tastes.
 *
 * @param int $user_id   Current user ID.
 * @param int $min_match Minimum matching sounds.
 * @param int $limit     Max users.
 * @return array Array of similar users with match count.
 */
function apollo_find_similar_users( $user_id, $min_match = 2, $limit = 20 ) {
	global $wpdb;

	$table   = $wpdb->prefix . 'apollo_user_sounds';
	$user_id = absint( $user_id );

	// Find users who share at least $min_match sounds
	$results = $wpdb->get_results(
		$wpdb->prepare(
			"SELECT 
				other.user_id,
				COUNT(DISTINCT other.sound_slug) as match_count,
				GROUP_CONCAT(DISTINCT other.sound_slug) as matched_sounds
			FROM $table AS current
			INNER JOIN $table AS other 
				ON current.sound_slug = other.sound_slug 
				AND other.user_id != current.user_id
			WHERE current.user_id = %d
			GROUP BY other.user_id
			HAVING match_count >= %d
			ORDER BY match_count DESC
			LIMIT %d",
			$user_id,
			$min_match,
			$limit
		)
	);

	$similar_users = array();

	foreach ( $results as $row ) {
		$user_data = get_userdata( $row->user_id );

		if ( ! $user_data ) {
			continue;
		}

		$similar_users[] = array(
			'user_id'        => (int) $row->user_id,
			'match_count'    => (int) $row->match_count,
			'matched_sounds' => explode( ',', $row->matched_sounds ),
			'display_name'   => $user_data->display_name,
			'avatar_url'     => get_avatar_url( $row->user_id, array( 'size' => 64 ) ),
		);
	}

	return $similar_users;
}

/**
 * Get events happening soon that match user's sounds.
 *
 * @param int $user_id User ID.
 * @param int $days    Days ahead to look.
 * @param int $limit   Max events.
 * @return array Events with match data.
 */
function apollo_get_upcoming_matched_events( $user_id, $days = 7, $limit = 5 ) {
	$user_sounds = apollo_get_user_sounds( $user_id );

	if ( empty( $user_sounds ) ) {
		return array();
	}

	$today    = current_time( 'Y-m-d' );
	$end_date = gmdate( 'Y-m-d', strtotime( "+{$days} days" ) );

	$args = array(
		'post_type'      => 'event_listing',
		'post_status'    => 'publish',
		'posts_per_page' => $limit,
		'meta_query'     => array(
			'relation' => 'AND',
			array(
				'key'     => '_event_date',
				'value'   => $today,
				'compare' => '>=',
				'type'    => 'DATE',
			),
			array(
				'key'     => '_event_date',
				'value'   => $end_date,
				'compare' => '<=',
				'type'    => 'DATE',
			),
		),
		'tax_query'      => array(
			array(
				'taxonomy' => 'event_sounds',
				'field'    => 'slug',
				'terms'    => $user_sounds,
				'operator' => 'IN',
			),
		),
		'orderby'        => 'meta_value',
		'order'          => 'ASC',
		'meta_key'       => '_event_date',
	);

	$query  = new WP_Query( $args );
	$events = array();

	foreach ( $query->posts as $event ) {
		$match = apollo_calculate_event_match_score( $user_id, $event->ID );

		$events[] = array(
			'event'      => $event,
			'match_data' => $match,
		);
	}

	return $events;
}

/**
 * Register REST endpoints for matchmaking.
 */
add_action( 'rest_api_init', 'apollo_register_matchmaking_routes' );

function apollo_register_matchmaking_routes() {
	register_rest_route( 'apollo/v1', '/matchmaking/events', array(
		'methods'             => 'GET',
		'callback'            => 'apollo_rest_get_matched_events',
		'permission_callback' => 'is_user_logged_in',
		'args'                => array(
			'limit' => array(
				'default'           => 10,
				'sanitize_callback' => 'absint',
			),
		),
	) );

	register_rest_route( 'apollo/v1', '/matchmaking/users', array(
		'methods'             => 'GET',
		'callback'            => 'apollo_rest_get_similar_users',
		'permission_callback' => 'is_user_logged_in',
		'args'                => array(
			'min_match' => array(
				'default'           => 2,
				'sanitize_callback' => 'absint',
			),
			'limit'     => array(
				'default'           => 20,
				'sanitize_callback' => 'absint',
			),
		),
	) );

	register_rest_route( 'apollo/v1', '/matchmaking/upcoming', array(
		'methods'             => 'GET',
		'callback'            => 'apollo_rest_get_upcoming_events',
		'permission_callback' => 'is_user_logged_in',
		'args'                => array(
			'days'  => array(
				'default'           => 7,
				'sanitize_callback' => 'absint',
			),
			'limit' => array(
				'default'           => 5,
				'sanitize_callback' => 'absint',
			),
		),
	) );

	register_rest_route( 'apollo/v1', '/matchmaking/score/(?P<event_id>\d+)', array(
		'methods'             => 'GET',
		'callback'            => 'apollo_rest_get_event_score',
		'permission_callback' => 'is_user_logged_in',
		'args'                => array(
			'event_id' => array(
				'required'          => true,
				'sanitize_callback' => 'absint',
			),
		),
	) );
}

function apollo_rest_get_matched_events( $request ) {
	$user_id = get_current_user_id();
	$limit   = $request->get_param( 'limit' );

	$events = apollo_get_recommended_events( $user_id, $limit );

	return new WP_REST_Response( array(
		'success' => true,
		'count'   => count( $events ),
		'events'  => $events,
	), 200 );
}

function apollo_rest_get_similar_users( $request ) {
	$user_id   = get_current_user_id();
	$min_match = $request->get_param( 'min_match' );
	$limit     = $request->get_param( 'limit' );

	$users = apollo_find_similar_users( $user_id, $min_match, $limit );

	return new WP_REST_Response( array(
		'success' => true,
		'count'   => count( $users ),
		'users'   => $users,
	), 200 );
}

function apollo_rest_get_upcoming_events( $request ) {
	$user_id = get_current_user_id();
	$days    = $request->get_param( 'days' );
	$limit   = $request->get_param( 'limit' );

	$events = apollo_get_upcoming_matched_events( $user_id, $days, $limit );

	return new WP_REST_Response( array(
		'success' => true,
		'count'   => count( $events ),
		'events'  => $events,
	), 200 );
}

function apollo_rest_get_event_score( $request ) {
	$user_id  = get_current_user_id();
	$event_id = $request->get_param( 'event_id' );

	$match = apollo_calculate_event_match_score( $user_id, $event_id );

	return new WP_REST_Response( array(
		'success'    => true,
		'event_id'   => $event_id,
		'match_data' => $match,
	), 200 );
}
