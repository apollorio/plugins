\# APOLLO CORE - SURGICAL IMPLEMENTATION PLAN

\## VS Code + Copilot + Opus Model Execution Guide

\*\*Version:\*\* 3.2.0

\*\*Complexity:\*\* Senior Expert Level

\*\*Estimated Time:\*\* 24-32 hours

\*\*Date:\*\* January 2026

---

\## 🔬 PRE-SURGERY AUDIT RESULTS

\### Files Analyzed (16 total)

| File | Status | Action Required |

|------|--------|-----------------|

| `new\_auth-scripts.php` | NEW | Integrate as `/assets/js/auth-scripts-inline.php` |

| `new\_auth-scripts.js` | NEW | Integrate as `/assets/js/auth-scripts.js` |

| `new\_login-register\_\_1\_.php` | NEW | Integrate as `/templates/auth/login-register.php` |

| `entre.php` | EXISTS (broken UTF-8) | REPLACE with fixed version |

| `registre.php` | EXISTS | UPDATE to handle sounds |

| `ajax-login-handler.php` | EXISTS | UPDATE AJAX endpoints |

| `quiz-tracker.php` | EXISTS | KEEP as-is |

| `quiz-defaults.php` | EXISTS | KEEP as-is |

| `schema-manager.php` | EXISTS | KEEP as-is |

| `attempts.php` | EXISTS | KEEP as-is |

| `rest.php` | EXISTS | KEEP as-is |

| `hide-wp-login.php` | EXISTS | KEEP as-is |

| `db-schema.php` | EXISTS | UPDATE for sounds table |

| `class-user-visit-tracker.php` | EXISTS | KEEP as-is |

| `class-apollo-db-query-optimizer.php` | EXISTS | KEEP as-is |

| `navbar-placeholder-data.php` | EXISTS | KEEP as-is |

\### Critical Issues Identified

1\. \*\*UTF-8 Encoding Broken\*\* in `entre.php` (Ã¡, Ã£, Ã§ characters)

2\. \*\*Sounds not stored\*\* during registration

3\. \*\*Missing user_sounds table\*\* in database schema

4\. \*\*Missing matchmaking logic\*\* for event_sounds

5\. \*\*new\_\* files not integrated\*\* into plugin structure

---

\## 📁 TARGET PLUGIN STRUCTURE

```

wp-content/plugins/apollo-core/

├── apollo-core.php                    # Main plugin file

├── includes/

│   ├── ajax/

│   │   ├── ajax-login-handler.php     # AJAX login (UPDATE)

│   │   └── ajax-register-handler.php  # AJAX registration (CREATE)

│   ├── auth/

│   │   ├── auth-routes.php            # Routes /entre, /registre

│   │   └── hide-wp-login.php          # WP-login redirect

│   ├── database/

│   │   ├── db-schema.php              # Main schema (UPDATE)

│   │   ├── user-sounds-schema.php     # User sounds table (CREATE)

│   │   └── class-apollo-db-query-optimizer.php

│   ├── quiz/

│   │   ├── quiz-tracker.php

│   │   ├── quiz-defaults.php

│   │   ├── schema-manager.php

│   │   ├── attempts.php

│   │   └── rest.php

│   ├── user/

│   │   ├── class-user-visit-tracker.php

│   │   └── user-sounds-handler.php    # Sound preferences (CREATE)

│   └── matchmaking/

│       └── sounds-matchmaking.php     # Event matchmaking (CREATE)

├── templates/

│   ├── auth/

│   │   ├── entre.php                  # Login page (REPLACE)

│   │   ├── registre.php               # Registration page (UPDATE)

│   │   └── login-register.php         # Combined template (CREATE)

│   └── parts/

│       ├── header.php

│       ├── footer.php

│       ├── login-form.php

│       ├── register-form.php

│       ├── lockout-overlay.php

│       └── aptitude-quiz.php

├── assets/

│   ├── css/

│   │   └── auth-styles.css

│   └── js/

│       ├── auth-scripts.js            # Main JS (from new\_)

│       └── auth-scripts-inline.php    # Inline config (from new\_)

└── languages/

&nbsp;   └── apollo-core-pt\_BR.po

```

---

\## 🗄️ DATABASE SCHEMA UPDATES

\### New Table: `wp\_apollo\_user\_sounds`

```sql

CREATE TABLE IF NOT EXISTS {$wpdb->prefix}apollo\_user\_sounds (

&nbsp;   id BIGINT(20) UNSIGNED NOT NULL AUTO\_INCREMENT,

&nbsp;   user\_id BIGINT(20) UNSIGNED NOT NULL,

&nbsp;   sound\_slug VARCHAR(50) NOT NULL,

&nbsp;   priority TINYINT(2) UNSIGNED DEFAULT 0,

&nbsp;   created\_at DATETIME DEFAULT CURRENT\_TIMESTAMP,

&nbsp;   PRIMARY KEY (id),

&nbsp;   UNIQUE KEY user\_sound\_unique (user\_id, sound\_slug),

&nbsp;   KEY user\_id\_idx (user\_id),

&nbsp;   KEY sound\_slug\_idx (sound\_slug),

&nbsp;   FOREIGN KEY (user\_id) REFERENCES {$wpdb->users}(ID) ON DELETE CASCADE

) {$charset\_collate};

```

\### Available Sounds (from event_sounds taxonomy)

```php

$available\_sounds = \[

&nbsp;   'techno'      => 'Techno',

&nbsp;   'house'       => 'House',

&nbsp;   'trance'      => 'Trance',

&nbsp;   'drum\_bass'   => 'Drum \& Bass',

&nbsp;   'funk'        => 'Funk',

&nbsp;   'tribal'      => 'Tribal',

&nbsp;   'minimal'     => 'Minimal',

&nbsp;   'progressive' => 'Progressive',

&nbsp;   'melodic'     => 'Melodico',

&nbsp;   'hard'        => 'Hard',

&nbsp;   'psy'         => 'Psy',

&nbsp;   'ambient'     => 'Ambient',

];

```

---

\## 🔧 VS CODE TASKS - EXECUTION ORDER

\### PHASE 1: Database Foundation (2-3 hours)

\#### Task 1.1: Create User Sounds Schema

\*\*File:\*\* `includes/database/user-sounds-schema.php`

```php

<?php

/\*\*

&nbsp;\* Apollo User Sounds Database Schema

&nbsp;\*

&nbsp;\* @package Apollo\_Core

&nbsp;\* @since 3.2.0

&nbsp;\*/



defined( 'ABSPATH' ) || exit;



function apollo\_create\_user\_sounds\_table() {

&nbsp;   global $wpdb;

&nbsp;

&nbsp;   $table\_name = $wpdb->prefix . 'apollo\_user\_sounds';

&nbsp;   $charset\_collate = $wpdb->get\_charset\_collate();

&nbsp;

&nbsp;   $sql = "CREATE TABLE IF NOT EXISTS $table\_name (

&nbsp;       id bigint(20) unsigned NOT NULL AUTO\_INCREMENT,

&nbsp;       user\_id bigint(20) unsigned NOT NULL,

&nbsp;       sound\_slug varchar(50) NOT NULL,

&nbsp;       priority tinyint(2) unsigned DEFAULT 0,

&nbsp;       created\_at datetime DEFAULT CURRENT\_TIMESTAMP,

&nbsp;       PRIMARY KEY (id),

&nbsp;       UNIQUE KEY user\_sound\_unique (user\_id, sound\_slug),

&nbsp;       KEY user\_id\_idx (user\_id),

&nbsp;       KEY sound\_slug\_idx (sound\_slug)

&nbsp;   ) $charset\_collate;";

&nbsp;

&nbsp;   require\_once ABSPATH . 'wp-admin/includes/upgrade.php';

&nbsp;   dbDelta( $sql );

&nbsp;

&nbsp;   update\_option( 'apollo\_user\_sounds\_db\_version', '1.0.0' );

}



function apollo\_get\_available\_sounds() {

&nbsp;   return apply\_filters( 'apollo\_available\_sounds', \[

&nbsp;       'techno'      => \_\_( 'Techno', 'apollo-core' ),

&nbsp;       'house'       => \_\_( 'House', 'apollo-core' ),

&nbsp;       'trance'      => \_\_( 'Trance', 'apollo-core' ),

&nbsp;       'drum\_bass'   => \_\_( 'Drum \& Bass', 'apollo-core' ),

&nbsp;       'funk'        => \_\_( 'Funk', 'apollo-core' ),

&nbsp;       'tribal'      => \_\_( 'Tribal', 'apollo-core' ),

&nbsp;       'minimal'     => \_\_( 'Minimal', 'apollo-core' ),

&nbsp;       'progressive' => \_\_( 'Progressive', 'apollo-core' ),

&nbsp;       'melodic'     => \_\_( 'Melodico', 'apollo-core' ),

&nbsp;       'hard'        => \_\_( 'Hard', 'apollo-core' ),

&nbsp;       'psy'         => \_\_( 'Psy', 'apollo-core' ),

&nbsp;       'ambient'     => \_\_( 'Ambient', 'apollo-core' ),

&nbsp;   ]);

}

```

\#### Task 1.2: Create User Sounds Handler

\*\*File:\*\* `includes/user/user-sounds-handler.php`

```php

<?php

/\*\*

&nbsp;\* Apollo User Sounds Handler

&nbsp;\*

&nbsp;\* Manages user sound/music genre preferences.

&nbsp;\*

&nbsp;\* @package Apollo\_Core

&nbsp;\* @since 3.2.0

&nbsp;\*/



defined( 'ABSPATH' ) || exit;



/\*\*

&nbsp;\* Save user sounds to database.

&nbsp;\*

&nbsp;\* @param int   $user\_id User ID.

&nbsp;\* @param array $sounds  Array of sound slugs.

&nbsp;\* @return bool True on success.

&nbsp;\*/

function apollo\_save\_user\_sounds( $user\_id, $sounds ) {

&nbsp;   global $wpdb;

&nbsp;

&nbsp;   $table = $wpdb->prefix . 'apollo\_user\_sounds';

&nbsp;   $user\_id = absint( $user\_id );

&nbsp;

&nbsp;   if ( ! $user\_id || empty( $sounds ) ) {

&nbsp;       return false;

&nbsp;   }

&nbsp;

&nbsp;   // Validate sounds against available list

&nbsp;   $available = array\_keys( apollo\_get\_available\_sounds() );

&nbsp;   $sounds = array\_intersect( (array) $sounds, $available );

&nbsp;

&nbsp;   if ( empty( $sounds ) ) {

&nbsp;       return false;

&nbsp;   }

&nbsp;

&nbsp;   // Delete existing sounds for user

&nbsp;   $wpdb->delete( $table, \[ 'user\_id' => $user\_id ], \[ '%d' ] );

&nbsp;

&nbsp;   // Insert new sounds with priority

&nbsp;   $priority = 0;

&nbsp;   foreach ( $sounds as $sound\_slug ) {

&nbsp;       $wpdb->insert(

&nbsp;           $table,

&nbsp;           \[

&nbsp;               'user\_id'    => $user\_id,

&nbsp;               'sound\_slug' => sanitize\_key( $sound\_slug ),

&nbsp;               'priority'   => $priority++,

&nbsp;           ],

&nbsp;           \[ '%d', '%s', '%d' ]

&nbsp;       );

&nbsp;   }

&nbsp;

&nbsp;   // Also store in user meta for quick access

&nbsp;   update\_user\_meta( $user\_id, 'apollo\_favorite\_sounds', $sounds );

&nbsp;

&nbsp;   do\_action( 'apollo\_user\_sounds\_saved', $user\_id, $sounds );

&nbsp;

&nbsp;   return true;

}



/\*\*

&nbsp;\* Get user sounds from database.

&nbsp;\*

&nbsp;\* @param int $user\_id User ID.

&nbsp;\* @return array Array of sound slugs.

&nbsp;\*/

function apollo\_get\_user\_sounds( $user\_id ) {

&nbsp;   global $wpdb;

&nbsp;

&nbsp;   $table = $wpdb->prefix . 'apollo\_user\_sounds';

&nbsp;   $user\_id = absint( $user\_id );

&nbsp;

&nbsp;   $sounds = $wpdb->get\_col(

&nbsp;       $wpdb->prepare(

&nbsp;           "SELECT sound\_slug FROM $table WHERE user\_id = %d ORDER BY priority ASC",

&nbsp;           $user\_id

&nbsp;       )

&nbsp;   );

&nbsp;

&nbsp;   return $sounds ?: \[];

}



/\*\*

&nbsp;\* Check if user has specific sound preference.

&nbsp;\*

&nbsp;\* @param int    $user\_id    User ID.

&nbsp;\* @param string $sound\_slug Sound slug.

&nbsp;\* @return bool True if user has this sound.

&nbsp;\*/

function apollo\_user\_has\_sound( $user\_id, $sound\_slug ) {

&nbsp;   $sounds = apollo\_get\_user\_sounds( $user\_id );

&nbsp;   return in\_array( sanitize\_key( $sound\_slug ), $sounds, true );

}



/\*\*

&nbsp;\* Get users by sound preference.

&nbsp;\*

&nbsp;\* @param string $sound\_slug Sound slug.

&nbsp;\* @param int    $limit      Max results.

&nbsp;\* @return array Array of user IDs.

&nbsp;\*/

function apollo\_get\_users\_by\_sound( $sound\_slug, $limit = 100 ) {

&nbsp;   global $wpdb;

&nbsp;

&nbsp;   $table = $wpdb->prefix . 'apollo\_user\_sounds';

&nbsp;

&nbsp;   return $wpdb->get\_col(

&nbsp;       $wpdb->prepare(

&nbsp;           "SELECT DISTINCT user\_id FROM $table WHERE sound\_slug = %s LIMIT %d",

&nbsp;           sanitize\_key( $sound\_slug ),

&nbsp;           absint( $limit )

&nbsp;       )

&nbsp;   );

}



/\*\*

&nbsp;\* Count users per sound.

&nbsp;\*

&nbsp;\* @return array Sound slug => count.

&nbsp;\*/

function apollo\_count\_users\_per\_sound() {

&nbsp;   global $wpdb;

&nbsp;

&nbsp;   $table = $wpdb->prefix . 'apollo\_user\_sounds';

&nbsp;

&nbsp;   $results = $wpdb->get\_results(

&nbsp;       "SELECT sound\_slug, COUNT(DISTINCT user\_id) as user\_count

&nbsp;        FROM $table

&nbsp;        GROUP BY sound\_slug

&nbsp;        ORDER BY user\_count DESC"

&nbsp;   );

&nbsp;

&nbsp;   $counts = \[];

&nbsp;   foreach ( $results as $row ) {

&nbsp;       $counts\[ $row->sound\_slug ] = (int) $row->user\_count;

&nbsp;   }

&nbsp;

&nbsp;   return $counts;

}

```

---

\### PHASE 2: Matchmaking System (3-4 hours)

\#### Task 2.1: Create Sounds Matchmaking

\*\*File:\*\* `includes/matchmaking/sounds-matchmaking.php`

```php

<?php

/\*\*

&nbsp;\* Apollo Sounds Matchmaking

&nbsp;\*

&nbsp;\* Matches users with events based on sound preferences.

&nbsp;\* Connects to event\_sounds taxonomy from post-types.php.

&nbsp;\*

&nbsp;\* @package Apollo\_Core

&nbsp;\* @since 3.2.0

&nbsp;\*/



defined( 'ABSPATH' ) || exit;



/\*\*

&nbsp;\* Get events matching user's sound preferences.

&nbsp;\*

&nbsp;\* @param int   $user\_id       User ID.

&nbsp;\* @param array $args          Query args.

&nbsp;\* @return array Array of event post objects.

&nbsp;\*/

function apollo\_get\_matched\_events\_for\_user( $user\_id, $args = \[] ) {

&nbsp;   $user\_sounds = apollo\_get\_user\_sounds( $user\_id );

&nbsp;

&nbsp;   if ( empty( $user\_sounds ) ) {

&nbsp;       return \[];

&nbsp;   }

&nbsp;

&nbsp;   $defaults = \[

&nbsp;       'post\_type'      => 'event\_listing',

&nbsp;       'post\_status'    => 'publish',

&nbsp;       'posts\_per\_page' => 20,

&nbsp;       'orderby'        => 'meta\_value',

&nbsp;       'order'          => 'ASC',

&nbsp;       'meta\_key'       => '\_event\_date',

&nbsp;       'meta\_query'     => \[

&nbsp;           \[

&nbsp;               'key'     => '\_event\_date',

&nbsp;               'value'   => current\_time( 'Y-m-d' ),

&nbsp;               'compare' => '>=',

&nbsp;               'type'    => 'DATE',

&nbsp;           ],

&nbsp;       ],

&nbsp;       'tax\_query'      => \[

&nbsp;           \[

&nbsp;               'taxonomy' => 'event\_sounds',

&nbsp;               'field'    => 'slug',

&nbsp;               'terms'    => $user\_sounds,

&nbsp;               'operator' => 'IN',

&nbsp;           ],

&nbsp;       ],

&nbsp;   ];

&nbsp;

&nbsp;   $query\_args = wp\_parse\_args( $args, $defaults );

&nbsp;

&nbsp;   $query = new WP\_Query( $query\_args );

&nbsp;

&nbsp;   return $query->posts;

}



/\*\*

&nbsp;\* Calculate match score between user and event.

&nbsp;\*

&nbsp;\* @param int $user\_id  User ID.

&nbsp;\* @param int $event\_id Event post ID.

&nbsp;\* @return array Match data with score.

&nbsp;\*/

function apollo\_calculate\_event\_match\_score( $user\_id, $event\_id ) {

&nbsp;   $user\_sounds = apollo\_get\_user\_sounds( $user\_id );

&nbsp;   $event\_sounds = wp\_get\_post\_terms( $event\_id, 'event\_sounds', \[ 'fields' => 'slugs' ] );

&nbsp;

&nbsp;   if ( is\_wp\_error( $event\_sounds ) ) {

&nbsp;       $event\_sounds = \[];

&nbsp;   }

&nbsp;

&nbsp;   $matched\_sounds = array\_intersect( $user\_sounds, $event\_sounds );

&nbsp;   $total\_user\_sounds = count( $user\_sounds );

&nbsp;   $total\_event\_sounds = count( $event\_sounds );

&nbsp;   $matched\_count = count( $matched\_sounds );

&nbsp;

&nbsp;   // Calculate percentage match

&nbsp;   $score = 0;

&nbsp;   if ( $total\_user\_sounds > 0 \&\& $total\_event\_sounds > 0 ) {

&nbsp;       // Weight: 70% based on user prefs, 30% based on event coverage

&nbsp;       $user\_match = ( $matched\_count / $total\_user\_sounds ) \* 70;

&nbsp;       $event\_match = ( $matched\_count / $total\_event\_sounds ) \* 30;

&nbsp;       $score = round( $user\_match + $event\_match );

&nbsp;   }

&nbsp;

&nbsp;   return \[

&nbsp;       'score'          => $score,

&nbsp;       'matched\_sounds' => $matched\_sounds,

&nbsp;       'user\_sounds'    => $user\_sounds,

&nbsp;       'event\_sounds'   => $event\_sounds,

&nbsp;       'match\_count'    => $matched\_count,

&nbsp;       'is\_perfect'     => $score >= 80,

&nbsp;       'is\_good'        => $score >= 50,

&nbsp;   ];

}



/\*\*

&nbsp;\* Get recommended events for user with match scores.

&nbsp;\*

&nbsp;\* @param int $user\_id User ID.

&nbsp;\* @param int $limit   Max events.

&nbsp;\* @return array Events with match data.

&nbsp;\*/

function apollo\_get\_recommended\_events( $user\_id, $limit = 10 ) {

&nbsp;   $events = apollo\_get\_matched\_events\_for\_user( $user\_id, \[

&nbsp;       'posts\_per\_page' => $limit \* 2, // Get more to sort by score

&nbsp;   ]);

&nbsp;

&nbsp;   $recommendations = \[];

&nbsp;

&nbsp;   foreach ( $events as $event ) {

&nbsp;       $match = apollo\_calculate\_event\_match\_score( $user\_id, $event->ID );

&nbsp;

&nbsp;       $recommendations\[] = \[

&nbsp;           'event'      => $event,

&nbsp;           'match\_data' => $match,

&nbsp;       ];

&nbsp;   }

&nbsp;

&nbsp;   // Sort by score descending

&nbsp;   usort( $recommendations, function( $a, $b ) {

&nbsp;       return $b\['match\_data']\['score'] - $a\['match\_data']\['score'];

&nbsp;   });

&nbsp;

&nbsp;   return array\_slice( $recommendations, 0, $limit );

}



/\*\*

&nbsp;\* Find users with similar sound tastes.

&nbsp;\*

&nbsp;\* @param int $user\_id       Current user ID.

&nbsp;\* @param int $min\_match     Minimum matching sounds.

&nbsp;\* @param int $limit         Max users.

&nbsp;\* @return array Array of similar users with match count.

&nbsp;\*/

function apollo\_find\_similar\_users( $user\_id, $min\_match = 2, $limit = 20 ) {

&nbsp;   global $wpdb;

&nbsp;

&nbsp;   $table = $wpdb->prefix . 'apollo\_user\_sounds';

&nbsp;   $user\_id = absint( $user\_id );

&nbsp;

&nbsp;   // Find users who share at least $min\_match sounds

&nbsp;   $results = $wpdb->get\_results(

&nbsp;       $wpdb->prepare(

&nbsp;           "SELECT

&nbsp;               other.user\_id,

&nbsp;               COUNT(DISTINCT other.sound\_slug) as match\_count

&nbsp;            FROM $table AS current

&nbsp;            INNER JOIN $table AS other

&nbsp;               ON current.sound\_slug = other.sound\_slug

&nbsp;               AND other.user\_id != current.user\_id

&nbsp;            WHERE current.user\_id = %d

&nbsp;            GROUP BY other.user\_id

&nbsp;            HAVING match\_count >= %d

&nbsp;            ORDER BY match\_count DESC

&nbsp;            LIMIT %d",

&nbsp;           $user\_id,

&nbsp;           $min\_match,

&nbsp;           $limit

&nbsp;       )

&nbsp;   );

&nbsp;

&nbsp;   $similar\_users = \[];

&nbsp;

&nbsp;   foreach ( $results as $row ) {

&nbsp;       $similar\_users\[] = \[

&nbsp;           'user\_id'     => (int) $row->user\_id,

&nbsp;           'match\_count' => (int) $row->match\_count,

&nbsp;           'user\_data'   => get\_userdata( $row->user\_id ),

&nbsp;       ];

&nbsp;   }

&nbsp;

&nbsp;   return $similar\_users;

}



/\*\*

&nbsp;\* Register REST endpoint for matchmaking.

&nbsp;\*/

add\_action( 'rest\_api\_init', function() {

&nbsp;   register\_rest\_route( 'apollo/v1', '/matchmaking/events', \[

&nbsp;       'methods'             => 'GET',

&nbsp;       'callback'            => 'apollo\_rest\_get\_matched\_events',

&nbsp;       'permission\_callback' => 'is\_user\_logged\_in',

&nbsp;       'args'                => \[

&nbsp;           'limit' => \[

&nbsp;               'default'           => 10,

&nbsp;               'sanitize\_callback' => 'absint',

&nbsp;           ],

&nbsp;       ],

&nbsp;   ]);

&nbsp;

&nbsp;   register\_rest\_route( 'apollo/v1', '/matchmaking/users', \[

&nbsp;       'methods'             => 'GET',

&nbsp;       'callback'            => 'apollo\_rest\_get\_similar\_users',

&nbsp;       'permission\_callback' => 'is\_user\_logged\_in',

&nbsp;   ]);

});



function apollo\_rest\_get\_matched\_events( $request ) {

&nbsp;   $user\_id = get\_current\_user\_id();

&nbsp;   $limit = $request->get\_param( 'limit' );

&nbsp;

&nbsp;   $events = apollo\_get\_recommended\_events( $user\_id, $limit );

&nbsp;

&nbsp;   return new WP\_REST\_Response( \[

&nbsp;       'success' => true,

&nbsp;       'events'  => $events,

&nbsp;   ], 200 );

}



function apollo\_rest\_get\_similar\_users( $request ) {

&nbsp;   $user\_id = get\_current\_user\_id();

&nbsp;

&nbsp;   $users = apollo\_find\_similar\_users( $user\_id );

&nbsp;

&nbsp;   // Remove sensitive data

&nbsp;   foreach ( $users as \&$user ) {

&nbsp;       if ( isset( $user\['user\_data'] ) \&\& $user\['user\_data'] ) {

&nbsp;           $user\['display\_name'] = $user\['user\_data']->display\_name;

&nbsp;           $user\['avatar'] = get\_avatar\_url( $user\['user\_id'], \[ 'size' => 64 ] );

&nbsp;           unset( $user\['user\_data'] );

&nbsp;       }

&nbsp;   }

&nbsp;

&nbsp;   return new WP\_REST\_Response( \[

&nbsp;       'success' => true,

&nbsp;       'users'   => $users,

&nbsp;   ], 200 );

}

```

---

\### PHASE 3: AJAX Registration Handler (2-3 hours)

\#### Task 3.1: Create AJAX Register Handler

\*\*File:\*\* `includes/ajax/ajax-register-handler.php`

```php

<?php

/\*\*

&nbsp;\* Apollo AJAX Registration Handler

&nbsp;\*

&nbsp;\* Handles user registration with sounds selection.

&nbsp;\*

&nbsp;\* @package Apollo\_Core

&nbsp;\* @since 3.2.0

&nbsp;\*/



defined( 'ABSPATH' ) || exit;



add\_action( 'wp\_ajax\_nopriv\_apollo\_register', 'apollo\_ajax\_register' );

add\_action( 'wp\_ajax\_apollo\_register', 'apollo\_ajax\_register' );



/\*\*

&nbsp;\* Process AJAX registration request.

&nbsp;\*/

function apollo\_ajax\_register() {

&nbsp;   // Verify nonce

&nbsp;   if ( ! isset( $\_POST\['nonce'] ) || ! wp\_verify\_nonce( sanitize\_text\_field( wp\_unslash( $\_POST\['nonce'] ) ), 'apollo\_auth\_nonce' ) ) {

&nbsp;       wp\_send\_json\_error( 'Sessao expirada. Recarregue a pagina.' );

&nbsp;   }

&nbsp;

&nbsp;   // Check if registration is allowed

&nbsp;   if ( ! get\_option( 'users\_can\_register' ) ) {

&nbsp;       wp\_send\_json\_error( 'Registro desabilitado.' );

&nbsp;   }

&nbsp;

&nbsp;   // Get and sanitize data

&nbsp;   $name       = isset( $\_POST\['user\_name'] ) ? sanitize\_text\_field( wp\_unslash( $\_POST\['user\_name'] ) ) : '';

&nbsp;   $instagram  = isset( $\_POST\['user\_instagram'] ) ? sanitize\_text\_field( wp\_unslash( $\_POST\['user\_instagram'] ) ) : '';

&nbsp;   $email      = isset( $\_POST\['user\_email'] ) ? sanitize\_email( wp\_unslash( $\_POST\['user\_email'] ) ) : '';

&nbsp;   $password   = isset( $\_POST\['user\_password'] ) ? $\_POST\['user\_password'] : '';

&nbsp;   $doc\_type   = isset( $\_POST\['doc\_type'] ) ? sanitize\_key( $\_POST\['doc\_type'] ) : 'cpf';

&nbsp;   $cpf        = isset( $\_POST\['user\_cpf'] ) ? sanitize\_text\_field( wp\_unslash( $\_POST\['user\_cpf'] ) ) : '';

&nbsp;   $passport   = isset( $\_POST\['user\_passport'] ) ? sanitize\_text\_field( wp\_unslash( $\_POST\['user\_passport'] ) ) : '';

&nbsp;   $sounds\_raw = isset( $\_POST\['user\_sounds'] ) ? wp\_unslash( $\_POST\['user\_sounds'] ) : '\[]';

&nbsp;

&nbsp;   // Parse sounds JSON

&nbsp;   $sounds = json\_decode( $sounds\_raw, true );

&nbsp;   if ( ! is\_array( $sounds ) ) {

&nbsp;       $sounds = \[];

&nbsp;   }

&nbsp;

&nbsp;   // Validations

&nbsp;   $errors = \[];

&nbsp;

&nbsp;   if ( empty( $name ) || strlen( $name ) < 2 ) {

&nbsp;       $errors\[] = 'Nome social e obrigatorio (minimo 2 caracteres).';

&nbsp;   }

&nbsp;

&nbsp;   if ( empty( $email ) || ! is\_email( $email ) ) {

&nbsp;       $errors\[] = 'E-mail invalido.';

&nbsp;   }

&nbsp;

&nbsp;   if ( email\_exists( $email ) ) {

&nbsp;       $errors\[] = 'Este e-mail ja esta cadastrado.';

&nbsp;   }

&nbsp;

&nbsp;   if ( strlen( $password ) < 8 ) {

&nbsp;       $errors\[] = 'Senha deve ter no minimo 8 caracteres.';

&nbsp;   }

&nbsp;

&nbsp;   if ( empty( $sounds ) ) {

&nbsp;       $errors\[] = 'Selecione pelo menos 1 genero musical.';

&nbsp;   }

&nbsp;

&nbsp;   // Validate sounds against available list

&nbsp;   $available\_sounds = array\_keys( apollo\_get\_available\_sounds() );

&nbsp;   $valid\_sounds = array\_intersect( $sounds, $available\_sounds );

&nbsp;

&nbsp;   if ( empty( $valid\_sounds ) ) {

&nbsp;       $errors\[] = 'Generos musicais invalidos.';

&nbsp;   }

&nbsp;

&nbsp;   if ( ! empty( $errors ) ) {

&nbsp;       wp\_send\_json\_error( implode( ' ', $errors ) );

&nbsp;   }

&nbsp;

&nbsp;   // Create username from email

&nbsp;   $username = sanitize\_user( strtok( $email, '@' ), true );

&nbsp;   $counter = 1;

&nbsp;   while ( username\_exists( $username ) ) {

&nbsp;       $username = sanitize\_user( strtok( $email, '@' ), true ) . $counter;

&nbsp;       $counter++;

&nbsp;   }

&nbsp;

&nbsp;   // Create user

&nbsp;   $user\_id = wp\_create\_user( $username, $password, $email );

&nbsp;

&nbsp;   if ( is\_wp\_error( $user\_id ) ) {

&nbsp;       wp\_send\_json\_error( $user\_id->get\_error\_message() );

&nbsp;   }

&nbsp;

&nbsp;   // Update user data

&nbsp;   wp\_update\_user( \[

&nbsp;       'ID'           => $user\_id,

&nbsp;       'display\_name' => $name,

&nbsp;       'first\_name'   => $name,

&nbsp;   ] );

&nbsp;

&nbsp;   // Save meta

&nbsp;   update\_user\_meta( $user\_id, 'apollo\_instagram', str\_replace( '@', '', $instagram ) );

&nbsp;   update\_user\_meta( $user\_id, 'apollo\_doc\_type', $doc\_type );

&nbsp;

&nbsp;   if ( 'cpf' === $doc\_type \&\& ! empty( $cpf ) ) {

&nbsp;       update\_user\_meta( $user\_id, 'apollo\_cpf', preg\_replace( '/\\D/', '', $cpf ) );

&nbsp;   } elseif ( 'passport' === $doc\_type \&\& ! empty( $passport ) ) {

&nbsp;       update\_user\_meta( $user\_id, 'apollo\_passport', strtoupper( $passport ) );

&nbsp;       update\_user\_meta( $user\_id, 'apollo\_passport\_limited', true );

&nbsp;   }

&nbsp;

&nbsp;   // CRITICAL: Save user sounds

&nbsp;   apollo\_save\_user\_sounds( $user\_id, $valid\_sounds );

&nbsp;

&nbsp;   // Mark quiz as registered

&nbsp;   if ( function\_exists( 'apollo\_quiz\_mark\_registered' ) ) {

&nbsp;       apollo\_quiz\_mark\_registered( $user\_id );

&nbsp;   }

&nbsp;

&nbsp;   // Log registration event

&nbsp;   do\_action( 'apollo\_user\_registered', $user\_id, \[

&nbsp;       'sounds'    => $valid\_sounds,

&nbsp;       'doc\_type'  => $doc\_type,

&nbsp;       'instagram' => $instagram,

&nbsp;   ] );

&nbsp;

&nbsp;   // Auto-login

&nbsp;   wp\_set\_current\_user( $user\_id );

&nbsp;   wp\_set\_auth\_cookie( $user\_id, true );

&nbsp;

&nbsp;   wp\_send\_json\_success( \[

&nbsp;       'message'      => 'Registro concluido com sucesso!',

&nbsp;       'redirect\_url' => home\_url( '/mural/?welcome=new' ),

&nbsp;       'user'         => \[

&nbsp;           'id'           => $user\_id,

&nbsp;           'display\_name' => $name,

&nbsp;           'avatar'       => get\_avatar\_url( $user\_id, \[ 'size' => 64 ] ),

&nbsp;           'sounds'       => $valid\_sounds,

&nbsp;       ],

&nbsp;   ] );

}

```

---

\### PHASE 4: Update Main Plugin File (2-3 hours)

\#### Task 4.1: Update apollo-core.php

\*\*Add to existing file after requires section:\*\*

```php

// =========================================================================

// USER SOUNDS SYSTEM

// =========================================================================

require\_once APOLLO\_CORE\_PATH . 'includes/database/user-sounds-schema.php';

require\_once APOLLO\_CORE\_PATH . 'includes/user/user-sounds-handler.php';

require\_once APOLLO\_CORE\_PATH . 'includes/matchmaking/sounds-matchmaking.php';

require\_once APOLLO\_CORE\_PATH . 'includes/ajax/ajax-register-handler.php';



// =========================================================================

// ACTIVATION HOOK - CREATE SOUNDS TABLE

// =========================================================================

register\_activation\_hook( APOLLO\_CORE\_FILE, 'apollo\_core\_create\_sounds\_table' );



function apollo\_core\_create\_sounds\_table() {

&nbsp;   if ( function\_exists( 'apollo\_create\_user\_sounds\_table' ) ) {

&nbsp;       apollo\_create\_user\_sounds\_table();

&nbsp;   }

}



// =========================================================================

// LOCALIZE SCRIPT FOR AUTH

// =========================================================================

add\_action( 'wp\_enqueue\_scripts', 'apollo\_localize\_auth\_config' );



function apollo\_localize\_auth\_config() {

&nbsp;   if ( ! is\_page( \[ 'entre', 'registre', 'login' ] ) ) {

&nbsp;       return;

&nbsp;   }

&nbsp;

&nbsp;   wp\_localize\_script( 'apollo-auth-scripts', 'APOLLO\_AUTH\_CONFIG', \[

&nbsp;       'ajaxUrl'         => admin\_url( 'admin-ajax.php' ),

&nbsp;       'nonce'           => wp\_create\_nonce( 'apollo\_auth\_nonce' ),

&nbsp;       'maxAttempts'     => 3,

&nbsp;       'lockoutDuration' => 30000,

&nbsp;       'sounds'          => apollo\_get\_available\_sounds(),

&nbsp;       'feedUrl'         => home\_url( '/mural/' ),

&nbsp;       'strings'         => \[

&nbsp;           'loginSuccess' => \_\_( 'Acesso autorizado. Redirecionando...', 'apollo-core' ),

&nbsp;           'loginFailed'  => \_\_( 'Credenciais incorretas. Tente novamente.', 'apollo-core' ),

&nbsp;           'quizComplete' => \_\_( 'Teste concluido!', 'apollo-core' ),

&nbsp;       ],

&nbsp;   ] );

}

```

---

\### PHASE 5: Update Registration Template (2-3 hours)

\#### Task 5.1: Add Sounds Selection to registre.php

\*\*Insert after password field (around line 500):\*\*

```php

<!-- SOUNDS SELECTION - MANDATORY -->

<div class="form-group sounds-group">

&nbsp;   <label class="form-label">Sons Favoritos <span class="required">\*</span></label>

&nbsp;   <p class="form-hint">Selecione pelo menos 1 genero musical</p>

&nbsp;   <div class="sounds-grid" id="sounds-grid">

&nbsp;       <?php

&nbsp;       $available\_sounds = apollo\_get\_available\_sounds();

&nbsp;       foreach ( $available\_sounds as $slug => $label ) :

&nbsp;       ?>

&nbsp;       <label class="sound-item">

&nbsp;           <input type="checkbox"

&nbsp;                  name="sounds\[]"

&nbsp;                  value="<?php echo esc\_attr( $slug ); ?>"

&nbsp;                  class="sound-checkbox">

&nbsp;           <span class="sound-label"><?php echo esc\_html( $label ); ?></span>

&nbsp;       </label>

&nbsp;       <?php endforeach; ?>

&nbsp;   </div>

&nbsp;   <div class="sounds-error" id="sounds-error" style="display:none;">

&nbsp;       Selecione pelo menos 1 genero musical

&nbsp;   </div>

</div>



<style>

.sounds-grid {

&nbsp;   display: grid;

&nbsp;   grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));

&nbsp;   gap: 10px;

&nbsp;   margin: 15px 0;

}



.sound-item {

&nbsp;   display: flex;

&nbsp;   align-items: center;

&nbsp;   padding: 10px 14px;

&nbsp;   background: rgba(255,255,255,0.05);

&nbsp;   border: 1px solid rgba(148,163,184,0.3);

&nbsp;   border-radius: 10px;

&nbsp;   cursor: pointer;

&nbsp;   transition: all 0.2s;

}



.sound-item:hover {

&nbsp;   background: rgba(255,255,255,0.08);

&nbsp;   border-color: var(--color-accent);

}



.sound-checkbox {

&nbsp;   display: none;

}



.sound-checkbox:checked + .sound-label {

&nbsp;   color: var(--color-accent);

&nbsp;   font-weight: 600;

}



.sound-item:has(.sound-checkbox:checked) {

&nbsp;   background: rgba(251,146,60,0.15);

&nbsp;   border-color: var(--color-accent);

}



.sound-label {

&nbsp;   font-size: 13px;

&nbsp;   color: rgba(248,250,252,0.8);

}



.sounds-error {

&nbsp;   color: var(--color-danger);

&nbsp;   font-size: 12px;

&nbsp;   margin-top: 8px;

}

</style>

```

---

\### PHASE 6: Fix entre.php UTF-8 (1 hour)

\#### Task 6.1: Replace entre.php

\*\*File already created in previous outputs - use fixed version with ASCII-safe text\*\*

Key changes:

\- Replace `Usuário` → `Usuario`

\- Replace `Você` → `Voce`

\- Replace `memória` → `memoria`

\- Replace `rápido` → `rapido`

\- All accented characters → ASCII equivalents

---

\### PHASE 7: Integration Testing (3-4 hours)

\#### Task 7.1: Test Checklist

```markdown
\## REGISTRATION FLOW TESTS

\[ ] /registre loads without 404

\[ ] Quiz (Simon game) completes successfully

\[ ] Step 2 shows registration form

\[ ] Sounds grid displays all 12 options

\[ ] At least 1 sound required validation works

\[ ] CPF validation (Brazilian algorithm) works

\[ ] Passport validation works

\[ ] User created in wp_users table

\[ ] Sounds saved in wp_apollo_user_sounds table

\[ ] User meta saved (instagram, doc_type, cpf/passport)

\[ ] Auto-login after registration works

\[ ] Redirect to /mural/?welcome=new works

\## LOGIN FLOW TESTS

\[ ] /entre loads without 404

\[ ] wp-login.php redirects to /entre

\[ ] Login with email works

\[ ] Login with username works

\[ ] Remember me checkbox works

\[ ] Failed login shows error

\[ ] 3 failed attempts triggers lockout

\[ ] Lockout timer displays correctly

\[ ] Successful login redirects properly

\## MATCHMAKING TESTS

\[ ] apollo_get_user_sounds() returns correct data

\[ ] apollo_get_matched_events_for_user() queries correctly

\[ ] apollo_calculate_event_match_score() calculates correctly

\[ ] REST endpoint /apollo/v1/matchmaking/events works

\[ ] REST endpoint /apollo/v1/matchmaking/users works

\## DATABASE TESTS

\[ ] wp_apollo_user_sounds table created

\[ ] Indexes created properly

\[ ] Unique constraint prevents duplicates

\[ ] CASCADE delete works when user deleted
```

---

\## 🚀 VS CODE EXECUTION COMMANDS

\### Step 1: Open Terminal in Plugin Directory

```bash

cd /path/to/wp-content/plugins/apollo-core/

```

\### Step 2: Create Directory Structure

```bash

mkdir -p includes/database

mkdir -p includes/user

mkdir -p includes/matchmaking

mkdir -p includes/ajax

mkdir -p templates/auth

mkdir -p templates/parts

mkdir -p assets/css

mkdir -p assets/js

```

\### Step 3: File Operations Order

1\. \*\*Create\*\* `includes/database/user-sounds-schema.php`

2\. \*\*Create\*\* `includes/user/user-sounds-handler.php`

3\. \*\*Create\*\* `includes/matchmaking/sounds-matchmaking.php`

4\. \*\*Create\*\* `includes/ajax/ajax-register-handler.php`

5\. \*\*Update\*\* `apollo-core.php` (add requires + hooks)

6\. \*\*Replace\*\* `templates/auth/entre.php` (UTF-8 fix)

7\. \*\*Update\*\* `templates/auth/registre.php` (add sounds)

8\. \*\*Copy\*\* `new\_auth-scripts.js` → `assets/js/auth-scripts.js`

9\. \*\*Copy\*\* `new\_auth-scripts.php` → `assets/js/auth-scripts-inline.php`

\### Step 4: Flush Rewrite Rules

```bash

wp rewrite flush

\# OR visit: yoursite.com/?apollo\_flush\_rules=1

```

\### Step 5: Verify Database Tables

```bash

wp db query "SHOW TABLES LIKE '%apollo%';"

wp db query "DESCRIBE wp\_apollo\_user\_sounds;"

```

---

\## 📊 COPILOT PROMPTS FOR EACH TASK

\### For Task 1.1 (User Sounds Schema):

```

Create WordPress database schema file for apollo\_user\_sounds table with columns: id, user\_id, sound\_slug, priority, created\_at. Include dbDelta, indexes, and helper function to get available sounds list.

```

\### For Task 2.1 (Matchmaking):

```

Create WordPress matchmaking system that queries event\_listing posts with event\_sounds taxonomy matching user's sound preferences stored in apollo\_user\_sounds table. Include match score calculation and REST endpoints.

```

\### For Task 3.1 (AJAX Register):

```

Create WordPress AJAX handler for user registration that validates sounds array, creates user with wp\_create\_user, saves sounds to custom table, and returns JSON response with user data.

```

---

\## ⚠️ CRITICAL REMINDERS

1\. \*\*Always verify nonces\*\* in AJAX handlers

2\. \*\*Sanitize all inputs\*\* with appropriate functions

3\. \*\*Use prepared statements\*\* for all database queries

4\. \*\*Flush rewrite rules\*\* after activation

5\. \*\*Test on staging\*\* before production

6\. \*\*Backup database\*\* before schema changes

---

\## 📋 FINAL VERIFICATION

After completing all tasks, run:

```bash

\# Syntax check all PHP files

find . -name "\*.php" -exec php -l {} \\;



\# Check for WordPress coding standards

composer require --dev wp-coding-standards/wpcs

./vendor/bin/phpcs --standard=WordPress includes/



\# Verify database tables

wp db query "SELECT COUNT(\*) FROM wp\_apollo\_user\_sounds;"

```

---

\*\*END OF SURGICAL PLAN\*\*

\*This plan was generated by Claude Opus 4.5 for execution in VS Code with Copilot assistance.\*

> ENTIRE PROMPT REQUEST INSIDE THE_PLAN.md ATTACHED.

SUPPORTIVE FILES:

"C:\Users\rafae\Local Sites\1212\app\public\wp-content\plugins\plan\ajax-register-handler.php"
"C:\Users\rafae\Local Sites\1212\app\public\wp-content\plugins\plan\sounds-matchmaking.php"
"C:\Users\rafae\Local Sites\1212\app\public\wp-content\plugins\plan\user-sounds-handler.php"
"C:\Users\rafae\Local Sites\1212\app\public\wp-content\plugins\plan\user-sounds-schema.php"

TO IMPLEMENT (all with prefix 'new\_' below):
"C:\Users\rafae\Local Sites\1212\app\public\wp-content\plugins\plan\new_auth"

"C:\Users\rafae\Local Sites\1212\app\public\wp-content\plugins\plan\new_auth\js"
"C:\Users\rafae\Local Sites\1212\app\public\wp-content\plugins\plan\new_auth\parts"
"C:\Users\rafae\Local Sites\1212\app\public\wp-content\plugins\plan\new_auth\new_login-register.php"
"C:\Users\rafae\Local Sites\1212\app\public\wp-content\plugins\plan\new_auth\css"

"C:\Users\rafae\Local Sites\1212\app\public\wp-content\plugins\plan\new_auth\parts\new_aptitude-quiz.php"
"C:\Users\rafae\Local Sites\1212\app\public\wp-content\plugins\plan\new_auth\parts\new_footer.php"
"C:\Users\rafae\Local Sites\1212\app\public\wp-content\plugins\plan\new_auth\parts\new_header.php"
"C:\Users\rafae\Local Sites\1212\app\public\wp-content\plugins\plan\new_auth\parts\new_lockout-overlay.php"
"C:\Users\rafae\Local Sites\1212\app\public\wp-content\plugins\plan\new_auth\parts\new_login-form.php"
"C:\Users\rafae\Local Sites\1212\app\public\wp-content\plugins\plan\new_auth\parts\new_register-form.php"

"C:\Users\rafae\Local Sites\1212\app\public\wp-content\plugins\plan\new_auth\js\new_auth-scripts.js"
"C:\Users\rafae\Local Sites\1212\app\public\wp-content\plugins\plan\new_auth\js\new_auth-scripts.php"

"C:\Users\rafae\Local Sites\1212\app\public\wp-content\plugins\plan\new_auth\css\new_auth-styles.css"
