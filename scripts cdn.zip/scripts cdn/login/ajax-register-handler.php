<?php
/**
 * Apollo AJAX Registration Handler
 *
 * Handles user registration with sounds selection.
 * Processes quiz completion and creates WP user.
 *
 * @package Apollo_Core
 * @since 3.2.0
 */

defined( 'ABSPATH' ) || exit;

add_action( 'wp_ajax_nopriv_apollo_register', 'apollo_ajax_register' );
add_action( 'wp_ajax_apollo_register', 'apollo_ajax_register' );

/**
 * Process AJAX registration request.
 *
 * @return void Outputs JSON response.
 */
function apollo_ajax_register() {
	// Verify nonce
	$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';

	if ( ! wp_verify_nonce( $nonce, 'apollo_auth_nonce' ) ) {
		wp_send_json_error( array(
			'code'    => 'invalid_nonce',
			'message' => 'Sessao expirada. Recarregue a pagina.',
		) );
	}

	// Check if registration is allowed
	if ( ! get_option( 'users_can_register' ) ) {
		wp_send_json_error( array(
			'code'    => 'registration_disabled',
			'message' => 'Registro desabilitado no momento.',
		) );
	}

	// Get and sanitize data
	$name       = isset( $_POST['user_name'] ) ? sanitize_text_field( wp_unslash( $_POST['user_name'] ) ) : '';
	$instagram  = isset( $_POST['user_instagram'] ) ? sanitize_text_field( wp_unslash( $_POST['user_instagram'] ) ) : '';
	$email      = isset( $_POST['user_email'] ) ? sanitize_email( wp_unslash( $_POST['user_email'] ) ) : '';
	$password   = isset( $_POST['user_password'] ) ? $_POST['user_password'] : '';
	$doc_type   = isset( $_POST['doc_type'] ) ? sanitize_key( $_POST['doc_type'] ) : 'cpf';
	$cpf        = isset( $_POST['user_cpf'] ) ? sanitize_text_field( wp_unslash( $_POST['user_cpf'] ) ) : '';
	$passport   = isset( $_POST['user_passport'] ) ? sanitize_text_field( wp_unslash( $_POST['user_passport'] ) ) : '';
	$sounds_raw = isset( $_POST['user_sounds'] ) ? wp_unslash( $_POST['user_sounds'] ) : '[]';

	// Parse sounds JSON
	$sounds = json_decode( $sounds_raw, true );
	if ( ! is_array( $sounds ) ) {
		$sounds = array();
	}

	// Validations
	$errors = array();

	// Name validation
	if ( empty( $name ) || strlen( $name ) < 2 ) {
		$errors[] = 'Nome social e obrigatorio (minimo 2 caracteres).';
	}

	if ( strlen( $name ) > 100 ) {
		$errors[] = 'Nome social muito longo (maximo 100 caracteres).';
	}

	// Email validation
	if ( empty( $email ) || ! is_email( $email ) ) {
		$errors[] = 'E-mail invalido.';
	}

	if ( email_exists( $email ) ) {
		$errors[] = 'Este e-mail ja esta cadastrado.';
	}

	// Password validation
	if ( strlen( $password ) < 8 ) {
		$errors[] = 'Senha deve ter no minimo 8 caracteres.';
	}

	if ( strlen( $password ) > 100 ) {
		$errors[] = 'Senha muito longa.';
	}

	// Sounds validation (mandatory)
	if ( empty( $sounds ) ) {
		$errors[] = 'Selecione pelo menos 1 genero musical.';
	}

	// Validate sounds against available list
	$available_sounds = array_keys( apollo_get_available_sounds() );
	$valid_sounds     = array_intersect( $sounds, $available_sounds );

	if ( ! empty( $sounds ) && empty( $valid_sounds ) ) {
		$errors[] = 'Generos musicais invalidos.';
	}

	// Document validation
	if ( 'cpf' === $doc_type && ! empty( $cpf ) ) {
		$cpf_clean = preg_replace( '/\D/', '', $cpf );
		if ( strlen( $cpf_clean ) !== 11 ) {
			$errors[] = 'CPF deve ter 11 digitos.';
		} elseif ( ! apollo_validate_cpf( $cpf_clean ) ) {
			$errors[] = 'CPF invalido.';
		}
	} elseif ( 'passport' === $doc_type && ! empty( $passport ) ) {
		$passport_clean = preg_replace( '/[^A-Za-z0-9]/', '', $passport );
		if ( strlen( $passport_clean ) < 6 || strlen( $passport_clean ) > 20 ) {
			$errors[] = 'Passaporte deve ter entre 6 e 20 caracteres.';
		}
	}

	// Rate limiting
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( $_SERVER['REMOTE_ADDR'] ) : '';
	if ( ! apollo_check_registration_rate_limit( $ip ) ) {
		$errors[] = 'Muitas tentativas. Aguarde alguns minutos.';
	}

	// Return errors if any
	if ( ! empty( $errors ) ) {
		wp_send_json_error( array(
			'code'    => 'validation_failed',
			'message' => implode( ' ', $errors ),
			'errors'  => $errors,
		) );
	}

	// Create username from email
	$username = sanitize_user( strtok( $email, '@' ), true );
	$counter  = 1;
	while ( username_exists( $username ) ) {
		$username = sanitize_user( strtok( $email, '@' ), true ) . $counter;
		$counter++;
	}

	// Create user
	$user_id = wp_create_user( $username, $password, $email );

	if ( is_wp_error( $user_id ) ) {
		wp_send_json_error( array(
			'code'    => 'user_creation_failed',
			'message' => $user_id->get_error_message(),
		) );
	}

	// Update user data
	wp_update_user( array(
		'ID'           => $user_id,
		'display_name' => $name,
		'first_name'   => $name,
	) );

	// Save meta
	$instagram_clean = str_replace( '@', '', $instagram );
	if ( ! empty( $instagram_clean ) ) {
		update_user_meta( $user_id, 'apollo_instagram', $instagram_clean );
	}

	update_user_meta( $user_id, 'apollo_doc_type', $doc_type );
	update_user_meta( $user_id, 'apollo_registration_date', current_time( 'mysql' ) );
	update_user_meta( $user_id, 'apollo_registration_ip', $ip );

	if ( 'cpf' === $doc_type && ! empty( $cpf ) ) {
		$cpf_clean = preg_replace( '/\D/', '', $cpf );
		update_user_meta( $user_id, 'apollo_cpf', $cpf_clean );
	} elseif ( 'passport' === $doc_type && ! empty( $passport ) ) {
		$passport_clean = strtoupper( preg_replace( '/[^A-Za-z0-9]/', '', $passport ) );
		update_user_meta( $user_id, 'apollo_passport', $passport_clean );
		update_user_meta( $user_id, 'apollo_passport_limited', true );
	}

	// CRITICAL: Save user sounds
	if ( function_exists( 'apollo_save_user_sounds' ) ) {
		apollo_save_user_sounds( $user_id, $valid_sounds );
	} else {
		// Fallback to user meta
		update_user_meta( $user_id, 'apollo_favorite_sounds', $valid_sounds );
	}

	// Mark quiz as registered
	if ( function_exists( 'apollo_quiz_mark_registered' ) ) {
		apollo_quiz_mark_registered( $user_id );
	}

	// Log registration event
	do_action( 'apollo_user_registered', $user_id, array(
		'sounds'    => $valid_sounds,
		'doc_type'  => $doc_type,
		'instagram' => $instagram_clean,
		'ip'        => $ip,
	) );

	// Auto-login
	wp_set_current_user( $user_id );
	wp_set_auth_cookie( $user_id, true );

	// Success response
	wp_send_json_success( array(
		'message'      => 'Registro concluido com sucesso!',
		'redirect_url' => apply_filters( 'apollo_registration_redirect', home_url( '/mural/?welcome=new' ), $user_id ),
		'user'         => array(
			'id'           => $user_id,
			'username'     => $username,
			'display_name' => $name,
			'email'        => $email,
			'avatar'       => get_avatar_url( $user_id, array( 'size' => 64 ) ),
			'sounds'       => $valid_sounds,
		),
	) );
}

/**
 * Validate Brazilian CPF number.
 *
 * @param string $cpf CPF digits only.
 * @return bool True if valid.
 */
function apollo_validate_cpf( $cpf ) {
	// Remove non-digits
	$cpf = preg_replace( '/\D/', '', $cpf );

	// Must be 11 digits
	if ( strlen( $cpf ) !== 11 ) {
		return false;
	}

	// Check for known invalid CPFs (all same digits)
	if ( preg_match( '/^(\d)\1{10}$/', $cpf ) ) {
		return false;
	}

	// Validate first check digit
	$sum = 0;
	for ( $i = 0; $i < 9; $i++ ) {
		$sum += (int) $cpf[ $i ] * ( 10 - $i );
	}
	$remainder = ( $sum * 10 ) % 11;
	if ( $remainder === 10 || $remainder === 11 ) {
		$remainder = 0;
	}
	if ( $remainder !== (int) $cpf[9] ) {
		return false;
	}

	// Validate second check digit
	$sum = 0;
	for ( $i = 0; $i < 10; $i++ ) {
		$sum += (int) $cpf[ $i ] * ( 11 - $i );
	}
	$remainder = ( $sum * 10 ) % 11;
	if ( $remainder === 10 || $remainder === 11 ) {
		$remainder = 0;
	}
	if ( $remainder !== (int) $cpf[10] ) {
		return false;
	}

	return true;
}

/**
 * Check registration rate limit.
 *
 * @param string $ip Client IP.
 * @return bool True if allowed.
 */
function apollo_check_registration_rate_limit( $ip ) {
	$transient_key = 'apollo_reg_rate_' . md5( $ip );
	$attempts      = get_transient( $transient_key );

	if ( false === $attempts ) {
		set_transient( $transient_key, 1, 15 * MINUTE_IN_SECONDS );
		return true;
	}

	// Max 5 attempts per 15 minutes
	if ( $attempts >= 5 ) {
		return false;
	}

	set_transient( $transient_key, $attempts + 1, 15 * MINUTE_IN_SECONDS );
	return true;
}

/**
 * AJAX handler for updating user sounds (logged-in users).
 */
add_action( 'wp_ajax_apollo_update_sounds', 'apollo_ajax_update_sounds' );

function apollo_ajax_update_sounds() {
	$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';

	if ( ! wp_verify_nonce( $nonce, 'apollo_auth_nonce' ) ) {
		wp_send_json_error( 'Sessao expirada.' );
	}

	$user_id    = get_current_user_id();
	$sounds_raw = isset( $_POST['sounds'] ) ? wp_unslash( $_POST['sounds'] ) : '[]';
	$sounds     = json_decode( $sounds_raw, true );

	if ( ! is_array( $sounds ) || empty( $sounds ) ) {
		wp_send_json_error( 'Selecione pelo menos 1 genero musical.' );
	}

	$available_sounds = array_keys( apollo_get_available_sounds() );
	$valid_sounds     = array_intersect( $sounds, $available_sounds );

	if ( empty( $valid_sounds ) ) {
		wp_send_json_error( 'Generos musicais invalidos.' );
	}

	$result = apollo_save_user_sounds( $user_id, $valid_sounds );

	if ( $result ) {
		wp_send_json_success( array(
			'message' => 'Preferencias atualizadas!',
			'sounds'  => $valid_sounds,
		) );
	} else {
		wp_send_json_error( 'Erro ao salvar preferencias.' );
	}
}
