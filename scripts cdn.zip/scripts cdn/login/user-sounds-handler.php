<?php
/**
 * Apollo User Sounds Handler
 *
 * Manages user sound/music genre preferences.
 * CRUD operations for wp_apollo_user_sounds table.
 *
 * @package Apollo_Core
 * @since 3.2.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Save user sounds to database.
 *
 * @param int   $user_id User ID.
 * @param array $sounds  Array of sound slugs.
 * @return bool True on success.
 */
if ( ! function_exists( 'apollo_save_user_sounds' ) ) {
function apollo_save_user_sounds( $user_id, $sounds ) {
	global $wpdb;

	$table   = $wpdb->prefix . 'apollo_user_sounds';
	$user_id = absint( $user_id );

	if ( ! $user_id || empty( $sounds ) ) {
		return false;
	}

	// Validate sounds against available list
	$available = array_keys( apollo_get_available_sounds() );
	$sounds    = array_intersect( (array) $sounds, $available );

	if ( empty( $sounds ) ) {
		return false;
	}

	// Delete existing sounds for user (replace strategy)
	$wpdb->delete( $table, array( 'user_id' => $user_id ), array( '%d' ) );

	// Insert new sounds with priority order
	$priority = 0;
	foreach ( $sounds as $sound_slug ) {
		$wpdb->insert(
			$table,
			array(
				'user_id'    => $user_id,
				'sound_slug' => sanitize_key( $sound_slug ),
				'priority'   => $priority++,
			),
			array( '%d', '%s', '%d' )
		);
	}

	// Also store in user meta for quick access
	update_user_meta( $user_id, 'apollo_favorite_sounds', $sounds );

	do_action( 'apollo_user_sounds_saved', $user_id, $sounds );

	return true;
}
}

/**
 * Get user sounds from database.
 *
 * @param int $user_id User ID.
 * @return array Array of sound slugs.
 */
if ( ! function_exists( 'apollo_get_user_sounds' ) ) {
function apollo_get_user_sounds( $user_id ) {
	global $wpdb;

	$table   = $wpdb->prefix . 'apollo_user_sounds';
	$user_id = absint( $user_id );

	if ( ! $user_id ) {
		return array();
	}

	// Try cache first
	$cache_key = 'apollo_user_sounds_' . $user_id;
	$cached    = wp_cache_get( $cache_key, 'apollo_sounds' );

	if ( false !== $cached ) {
		return $cached;
	}

	$sounds = $wpdb->get_col(
		$wpdb->prepare(
			"SELECT sound_slug FROM $table WHERE user_id = %d ORDER BY priority ASC",
			$user_id
		)
	);

	$result = $sounds ?: array();

	// Cache for 1 hour
	wp_cache_set( $cache_key, $result, 'apollo_sounds', HOUR_IN_SECONDS );

	return $result;
}
}

/**
 * Add a single sound to user preferences.
 *
 * @param int    $user_id    User ID.
 * @param string $sound_slug Sound slug.
 * @return bool True on success.
 */
if ( ! function_exists( 'apollo_add_user_sound' ) ) {
function apollo_add_user_sound( $user_id, $sound_slug ) {
	global $wpdb;

	$table      = $wpdb->prefix . 'apollo_user_sounds';
	$user_id    = absint( $user_id );
	$sound_slug = sanitize_key( $sound_slug );

	// Validate sound exists
	$available = array_keys( apollo_get_available_sounds() );
	if ( ! in_array( $sound_slug, $available, true ) ) {
		return false;
	}

	// Get current max priority
	$max_priority = $wpdb->get_var(
		$wpdb->prepare(
			"SELECT MAX(priority) FROM $table WHERE user_id = %d",
			$user_id
		)
	);

	$priority = $max_priority ? $max_priority + 1 : 0;

	// Insert (will fail silently if duplicate due to unique key)
	$result = $wpdb->insert(
		$table,
		array(
			'user_id'    => $user_id,
			'sound_slug' => $sound_slug,
			'priority'   => $priority,
		),
		array( '%d', '%s', '%d' )
	);

	if ( $result ) {
		// Invalidate cache
		wp_cache_delete( 'apollo_user_sounds_' . $user_id, 'apollo_sounds' );

		// Update user meta
		$sounds   = apollo_get_user_sounds( $user_id );
		$sounds[] = $sound_slug;
		update_user_meta( $user_id, 'apollo_favorite_sounds', array_unique( $sounds ) );
	}

	return (bool) $result;
}
}

/**
 * Remove a single sound from user preferences.
 *
 * @param int    $user_id    User ID.
 * @param string $sound_slug Sound slug.
 * @return bool True on success.
 */
if ( ! function_exists( 'apollo_remove_user_sound' ) ) {
function apollo_remove_user_sound( $user_id, $sound_slug ) {
	global $wpdb;

	$table   = $wpdb->prefix . 'apollo_user_sounds';
	$user_id = absint( $user_id );

	$result = $wpdb->delete(
		$table,
		array(
			'user_id'    => $user_id,
			'sound_slug' => sanitize_key( $sound_slug ),
		),
		array( '%d', '%s' )
	);

	if ( $result ) {
		// Invalidate cache
		wp_cache_delete( 'apollo_user_sounds_' . $user_id, 'apollo_sounds' );

		// Update user meta
		$sounds = apollo_get_user_sounds( $user_id );
		$sounds = array_diff( $sounds, array( $sound_slug ) );
		update_user_meta( $user_id, 'apollo_favorite_sounds', array_values( $sounds ) );
	}

	return (bool) $result;
}
}

/**
 * Check if user has specific sound preference.
 *
 * @param int    $user_id    User ID.
 * @param string $sound_slug Sound slug.
 * @return bool True if user has this sound.
 */
if ( ! function_exists( 'apollo_user_has_sound' ) ) {
function apollo_user_has_sound( $user_id, $sound_slug ) {
	$sounds = apollo_get_user_sounds( $user_id );
	return in_array( sanitize_key( $sound_slug ), $sounds, true );
}
}

/**
 * Get users by sound preference.
 *
 * @param string $sound_slug Sound slug.
 * @param int    $limit      Max results.
 * @param int    $offset     Offset for pagination.
 * @return array Array of user IDs.
 */
if ( ! function_exists( 'apollo_get_users_by_sound' ) ) {
function apollo_get_users_by_sound( $sound_slug, $limit = 100, $offset = 0 ) {
	global $wpdb;

	$table = $wpdb->prefix . 'apollo_user_sounds';

	return $wpdb->get_col(
		$wpdb->prepare(
			"SELECT DISTINCT user_id FROM $table WHERE sound_slug = %s LIMIT %d OFFSET %d",
			sanitize_key( $sound_slug ),
			absint( $limit ),
			absint( $offset )
		)
	);
}
}

/**
 * Count users per sound.
 *
 * @return array Sound slug => count.
 */
if ( ! function_exists( 'apollo_count_users_per_sound' ) ) {
function apollo_count_users_per_sound() {
	global $wpdb;

	$table = $wpdb->prefix . 'apollo_user_sounds';

	// Try cache
	$cached = wp_cache_get( 'apollo_sound_counts', 'apollo_sounds' );
	if ( false !== $cached ) {
		return $cached;
	}

	$results = $wpdb->get_results(
		"SELECT sound_slug, COUNT(DISTINCT user_id) as user_count
		 FROM $table
		 GROUP BY sound_slug
		 ORDER BY user_count DESC"
	);

	$counts = array();
	foreach ( $results as $row ) {
		$counts[ $row->sound_slug ] = (int) $row->user_count;
	}

	// Cache for 1 hour
	wp_cache_set( 'apollo_sound_counts', $counts, 'apollo_sounds', HOUR_IN_SECONDS );

	return $counts;
}
}

/**
 * Get sound statistics for admin dashboard.
 *
 * @return array Statistics.
 */
if ( ! function_exists( 'apollo_get_sounds_statistics' ) ) {
function apollo_get_sounds_statistics() {
	global $wpdb;

	$table = $wpdb->prefix . 'apollo_user_sounds';

	$stats = $wpdb->get_row(
		"SELECT
			COUNT(DISTINCT user_id) as total_users_with_sounds,
			COUNT(*) as total_sound_selections,
			AVG(sounds_per_user.cnt) as avg_sounds_per_user
		FROM $table
		JOIN (
			SELECT user_id, COUNT(*) as cnt
			FROM $table
			GROUP BY user_id
		) as sounds_per_user ON 1=1"
	);

	return array(
		'total_users'       => (int) $stats->total_users_with_sounds,
		'total_selections'  => (int) $stats->total_sound_selections,
		'avg_per_user'      => round( (float) $stats->avg_sounds_per_user, 2 ),
		'counts_by_sound'   => apollo_count_users_per_sound(),
	);
}
}

/**
 * Clean up sounds when user is deleted.
 *
 * @param int $user_id User ID being deleted.
 * @return void
 */
if ( ! function_exists( 'apollo_cleanup_user_sounds' ) ) {
function apollo_cleanup_user_sounds( $user_id ) {
	global $wpdb;

	$table = $wpdb->prefix . 'apollo_user_sounds';

	$wpdb->delete( $table, array( 'user_id' => absint( $user_id ) ), array( '%d' ) );

	// Invalidate cache
	wp_cache_delete( 'apollo_user_sounds_' . $user_id, 'apollo_sounds' );
	wp_cache_delete( 'apollo_sound_counts', 'apollo_sounds' );
}
}
add_action( 'delete_user', 'apollo_cleanup_user_sounds' );
