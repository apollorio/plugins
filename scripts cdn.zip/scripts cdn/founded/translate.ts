/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * TRANSLATE.TS v2.2.4
 * Lightweight Language Detection & Translation Utility with TanStack Query Integration
 * ═══════════════════════════════════════════════════════════════════════════════
 *
 * YOUNG TONE - Modern Brazilian Portuguese with preserved English loanwords
 *
 * Features:
 * • Native Intl.PluralRules
 * • Lazy dictionary loading (enhanced with TanStack Query for caching, retries, and bug prevention)
 * • Tone/cultural scoping ("formal", "young", "slang")
 * • Loanword preservation (tech/English terms)
 * • requestIdleCallback non-blocking
 * • ApolloTrack metrics integration
 * • Viewport/input detection
 *
 * @version 2.2.4
 * @license MIT
 * @updated 2026-01-22
 */

// UMD wrapper for TypeScript module
((root: any, factory: () => TranslateAPI) => {
  'use strict';
  if (typeof exports === 'object' && typeof module !== 'undefined') {
    module.exports = factory();
  } else if (typeof define === 'function' && define.amd) {
    define(factory);
  } else {
    root.Translate = factory();
  }
})(typeof globalThis !== 'undefined' ? globalThis : typeof window !== 'undefined' ? window : this, () => {
  'use strict';

  // ═══════════════════════════════════════════════════════════════════════════
  // TYPES & INTERFACES
  // ═══════════════════════════════════════════════════════════════════════════

  interface TranslateOptions {
    lang?: string;
    tone?: string;
    vars?: Record<string, any>;
    count?: number;
    fallback?: string;
  }

  interface PluralForms {
    zero?: string;
    one?: string;
    two?: string;
    few?: string;
    many?: string;
    other: string;
  }

  interface UIContext {
    viewport: { width: number; height: number; dpr: number };
    input: { pointer: 'coarse' | 'fine' };
    scroll: { locked: boolean; axis: 'x' | 'y' };
  }

  interface ScrollOptions {
    axis?: 'x' | 'y';
    lock?: boolean;
    threshold?: number;
    onEnter?: (target: Element) => void;
    onExit?: (target: Element) => void;
  }

  interface ObserveOptions {
    immediate?: boolean;
    lang?: string;
    tone?: string;
  }

  interface DataAttributes {
    TRANSLATE: 'data-translate';
    TRANSLATED: 'data-translated';
    ORIGINAL: 'data-original';
    LOCKED: 'data-locked';
    LANG: 'data-lang';
    VARS: 'data-vars';
    COUNT: 'data-count';
    TONE: 'data-tone';
    VIEWPORT_WIDTH: 'data-viewport-width';
    VIEWPORT_HEIGHT: 'data-viewport-height';
    DPR: 'data-dpr';
    POINTER: 'data-pointer';
    SCROLL_LOCK: 'data-scroll-lock';
    SCROLL_AXIS: 'data-scroll-axis';
  }

  interface TranslateAPI {
    version: string;
    config: (opts: Partial<{ basePath: string; defaultTone: string; metrics: boolean; metricsCallback: (name: string, data: any) => void }>) => TranslateAPI;
    lang: string;
    detect: () => string;
    context: Readonly<UIContext & { lang: string; languages: string[]; locked: string[]; tones: string[]; basePath: string; defaultTone: string; metricsEnabled: boolean }>;
    languages: string[];
    supports: (lang: string) => boolean;
    onLangChange: (fn: (newLang: string, oldLang: string) => void) => () => void;
    register: (lang: string, translations: Record<string, any>, tone?: string) => TranslateAPI;
    registerAll: (map: Record<string, Record<string, any>>, tone?: string) => TranslateAPI;
    load: (lang: string, tone?: string) => Promise<boolean>;
    preload: (langs: string | string[], tone?: string) => Promise<void>;
    clear: (lang: string, tone?: string) => boolean;
    clearAll: () => TranslateAPI;
    reloadDict: (lang: string, tone?: string) => Promise<boolean>;
    lock: (...terms: (string | RegExp)[]) => TranslateAPI;
    unlock: (term: string | RegExp) => boolean;
    unlockPatterns: () => TranslateAPI;
    disableAutoLoanwords: () => TranslateAPI;
    locked: string[];
    lockedPatterns: RegExp[];
    isLocked: (text: string) => boolean;
    get: (key: string, opts?: TranslateOptions) => string;
    getAsync: (key: string, opts?: TranslateOptions) => Promise<string>;
    has: (key: string, lang?: string, tone?: string) => boolean;
    apply: (root?: Element, lang?: string, tone?: string) => number;
    applyAsync: (root?: Element, lang?: string, tone?: string) => Promise<number>;
    restore: (root?: Element) => number;
    retranslate: (root?: Element, lang?: string, tone?: string) => number;
    observe: (root?: Element, opts?: ObserveOptions) => () => void;
    unobserve: (root?: Element) => boolean;
    unobserveAll: () => number;
    observeScroll: (root?: Element, opts?: ScrollOptions) => () => void;
    unobserveScroll: (root?: Element) => boolean;
    detectContext: () => void;
    observeContext: () => () => void;
    stopObserveContext: () => boolean;
    interp: (str: string, vars: Record<string, any>) => string;
    plural: (forms: PluralForms | string, count: number, lang?: string) => string;
    scope: (namespace: string, tone?: string) => { get: (key: string, opts?: TranslateOptions) => string; has: (key: string, lang?: string) => boolean; tone: string };
    tone: (toneName: string) => { get: (key: string, opts?: TranslateOptions) => string; has: (key: string, lang?: string) => boolean; apply: (root?: Element, lang?: string) => number; scope: (ns: string) => any };
    export: () => Record<string, Record<string, any>>;
    import: (data: Record<string, Record<string, any>>) => TranslateAPI;
    ATTR: Readonly<DataAttributes>;
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // ENVIRONMENT
  // ═══════════════════════════════════════════════════════════════════════════

  const doc: Document | null = typeof document !== 'undefined' ? document : null;
  const docEl: HTMLElement | undefined = doc?.documentElement;
  const win: Window & typeof globalThis = typeof window !== 'undefined' ? window : {} as any;
  const nav: Navigator = typeof navigator !== 'undefined' ? navigator : {} as any;

  const getBody = (): HTMLElement | null => doc?.body ?? null;

  const hasIntlPlural: boolean = typeof Intl !== 'undefined' && !!Intl.PluralRules;
  const hasIdleCallback: boolean = 'requestIdleCallback' in win;
  const hasMutationObserver: boolean = typeof MutationObserver !== 'undefined';
  const hasIntersectionObserver: boolean = typeof IntersectionObserver !== 'undefined';
  const hasMatchMedia: boolean = 'matchMedia' in win;

  // Idle callback with fallback
  const rIC: (fn: IdleRequestCallback) => number = hasIdleCallback
    ? win.requestIdleCallback.bind(win)
    : (fn: IdleRequestCallback) => setTimeout(() => fn({ timeRemaining: () => 50, didTimeout: false }), 1);

  // ═══════════════════════════════════════════════════════════════════════════
  // INTERNAL STATE (monomorphic objects for V8 optimization)
  // ═══════════════════════════════════════════════════════════════════════════

  /** lang -> { key -> translation } */
  const _dicts: Map<string, Map<string, any>> = new Map();

  /** Pending dict fetches */
  const _pending: Map<string, Promise<boolean>> = new Map();

  /** Locked terms (lowercase) */
  const _locked: Set<string> = new Set();

  /** Locked patterns (for loanwords) */
  const _lockedPatterns: Set<RegExp> = new Set();

  /** Active observers */
  const _observers: Map<Element, MutationObserver> = new Map();

  /** Language change listeners */
  const _listeners: Set<(newLang: string, oldLang: string) => void> = new Set();

  /** PluralRules cache */
  const _pluralCache: Map<string, Intl.PluralRules> = new Map();

  /** Scroll observers */
  const _scrollObservers: Map<Element, IntersectionObserver> = new Map();

  let _lang: string | null = null;
  let _langManual: boolean = false;
  let _basePath: string = '/locales';
  let _defaultTone: string = 'default';
  let _metricsEnabled: boolean = false;
  let _metricsCallback: ((name: string, data: any) => void) | null = null;
  const _fallback: string = 'en';

  // Default loanword patterns (English tech terms for PT-BR/ES/FR etc.)
  const DEFAULT_LOANWORD_PATTERNS: RegExp[] = [
    /\b(?:app|link|post|feed|like|share|story|selfie|login|logout|hashtag|follow|chat|dm|live|stream|upload|download|update|bug|fix|feature|api|sdk|ui|ux|web|mobile|appstore|playstore|iphone|android|google|whatsapp|instagram|facebook|twitter|x|online|offline|browser|server|client|code|debug|test|deploy|version|release|beta|alpha|pro|max|mini|plus|ultra)\b/gi
  ];

  // Apply defaults
  DEFAULT_LOANWORD_PATTERNS.forEach(p => _lockedPatterns.add(p));

  // UI Context state
  let _context: UIContext = {
    viewport: { width: win.innerWidth || 0, height: win.innerHeight || 0, dpr: win.devicePixelRatio || 1 },
    input: { pointer: hasMatchMedia && win.matchMedia('(pointer: coarse)').matches ? 'coarse' : 'fine' },
    scroll: { locked: false, axis: 'y' } // default vertical scroll
  };

  // TanStack Query Integration (global assumption from CDN load)
  let queryClient: any | null = null;
  if ((win as any).QueryClient) {
    queryClient = new (win as any).QueryClient({
      defaultOptions: {
        queries: {
          staleTime: 86400000, // 24h, matching localStorage TTL
          retry: 3, // Bug prevention: Retry failed dict fetches
          refetchOnWindowFocus: false, // Avoid unnecessary refetches
        }
      }
    });
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // DATA ATTRIBUTES
  // ═══════════════════════════════════════════════════════════════════════════

  const A: Readonly<DataAttributes> = Object.freeze({
    TRANSLATE: 'data-translate',
    TRANSLATED: 'data-translated',
    ORIGINAL: 'data-original',
    LOCKED: 'data-locked',
    LANG: 'data-lang',
    VARS: 'data-vars',
    COUNT: 'data-count',
    TONE: 'data-tone',
    VIEWPORT_WIDTH: 'data-viewport-width',
    VIEWPORT_HEIGHT: 'data-viewport-height',
    DPR: 'data-dpr',
    POINTER: 'data-pointer',
    SCROLL_LOCK: 'data-scroll-lock',
    SCROLL_AXIS: 'data-scroll-axis'
  });

  // ═══════════════════════════════════════════════════════════════════════════
  // LANGUAGE DETECTION (no regex in hot path)
  // ═══════════════════════════════════════════════════════════════════════════

  /**
   * Normalize language code - optimized (no regex)
   * "en-US" -> "en", "pt-BR" -> "pt"
   */
  const normLang = (code: string | null | undefined): string => {
    if (!code || typeof code !== 'string') return _fallback;
    const c = code.toLowerCase().trim();
    const dash = c.indexOf('-');
    const under = c.indexOf('_');
    const sep = dash > -1 ? dash : under > -1 ? under : c.length;
    return c.slice(0, Math.min(sep, 2)) || _fallback;
  };

  /**
   * Detect language from environment
   */
  const detectLang = (): string => {
    if (_langManual && _lang) return _lang;
    try {
      const body = getBody();
      return normLang(
        body?.dataset?.lang ||
        docEl?.lang ||
        nav?.language ||
        _fallback
      );
    } catch {
      return _fallback;
    }
  };

  // ═══════════════════════════════════════════════════════════════════════════
  // UI CONTEXT DETECTION & MIRRORING
  // ═══════════════════════════════════════════════════════════════════════════

  /**
   * Detect and mirror UI context to body data-*
   */
  const detectContext = (): void => {
    const body = getBody();
    if (!body) return;

    // Viewport
    _context.viewport = {
      width: win.innerWidth,
      height: win.innerHeight,
      dpr: win.devicePixelRatio || 1
    };
    body.setAttribute(A.VIEWPORT_WIDTH, _context.viewport.width.toString());
    body.setAttribute(A.VIEWPORT_HEIGHT, _context.viewport.height.toString());
    body.setAttribute(A.DPR, _context.viewport.dpr.toString());

    // Input (pointer: fine/coarse)
    _context.input.pointer = hasMatchMedia && win.matchMedia('(pointer: coarse)').matches ? 'coarse' : 'fine';
    body.setAttribute(A.POINTER, _context.input.pointer);

    // Scroll (initial unlocked)
    body.setAttribute(A.SCROLL_LOCK, 'false');
    body.setAttribute(A.SCROLL_AXIS, 'y');
  };

  /** Resize listener reference for cleanup */
  let _resizeHandler: ((this: Window, ev: UIEvent) => any) | null = null;

  /**
   * Listen for resize/orientation changes
   * @returns {Function} Cleanup function
   */
  const observeContext = (): () => void => {
    if (_resizeHandler) return () => {}; // Already observing

    _resizeHandler = debounce(detectContext, 200);
    win.addEventListener('resize', _resizeHandler);
    detectContext(); // initial

    return () => {
      if (_resizeHandler) {
        win.removeEventListener('resize', _resizeHandler);
        _resizeHandler = null;
      }
    };
  };

  // ═══════════════════════════════════════════════════════════════════════════
  // INTL PLURAL RULES (native, cached)
  // ═══════════════════════════════════════════════════════════════════════════

  /**
   * Get plural category using native Intl.PluralRules
   * Falls back to simple "one/other" if Intl unavailable
   */
  const getPlural = (count: number, lang: string): Intl.LDMLPluralRule => {
    if (!hasIntlPlural) {
      return Math.abs(count) === 1 ? 'one' : 'other';
    }

    // Cache PluralRules instances
    if (!_pluralCache.has(lang)) {
      try {
        _pluralCache.set(lang, new Intl.PluralRules(lang));
      } catch {
        _pluralCache.set(lang, new Intl.PluralRules('en'));
      }
    }

    return _pluralCache.get(lang)!.select(count);
  };

  /**
   * Select plural form from object
   */
  const selectPlural = (forms: PluralForms | string, count: number, lang: string): string => {
    if (typeof forms === 'string') return forms;
    if (!forms || typeof forms !== 'object') return '';

    const rule = getPlural(count, lang);
    return forms[rule] || forms.other || forms.one || Object.values(forms)[0] || '';
  };

  // ═══════════════════════════════════════════════════════════════════════════
  // INTERPOLATION (optimized, no regex in simple cases)
  // ═══════════════════════════════════════════════════════════════════════════

  /**
   * Interpolate {placeholders} in string
   * Optimized: skip regex if no { found
   */
  const interp = (str: string, vars: Record<string, any> | null | undefined): string => {
    if (!vars || typeof vars !== 'object' || typeof str !== 'string' || str.indexOf('{') === -1) return str;

    // Use replace only when needed
    return str.replace(/\{(\w+)\}/g, (m: string, k: string): string =>
      Object.prototype.hasOwnProperty.call(vars, k) ? String(vars[k]) : m
    );
  };

  // ═══════════════════════════════════════════════════════════════════════════
  // LOCKED TERMS
  // ═══════════════════════════════════════════════════════════════════════════

  const isLocked = (text: string | null | undefined): boolean => {
    if (!text) return false;

    // Check exact terms
    if (_locked.size > 0) {
      const lower = text.toLowerCase();
      for (const term of _locked) {
        if (lower.indexOf(term) > -1) return true;
      }
    }

    // Check regex patterns (for loanwords)
    if (_lockedPatterns.size > 0) {
      for (const pattern of _lockedPatterns) {
        if (pattern.test(text)) return true;
      }
    }

    return false;
  };

  // ═══════════════════════════════════════════════════════════════════════════
  // LAZY DICTIONARY LOADING (Enhanced with TanStack Query)
  // ═══════════════════════════════════════════════════════════════════════════

  /**
   * Fetch dictionary from CDN/server using TanStack Query if available (for caching, retries, bug prevention)
   * Falls back to native fetch + localStorage
   */
  const fetchDict = async (lang: string, tone: string = _defaultTone): Promise<boolean> => {
    const key = `${lang}:${tone}`;

    // Already loaded
    if (_dicts.has(key)) return true;

    // Already fetching (use TanStack's built-in deduping if available)
    if (_pending.has(key)) {
      return _pending.get(key)!.then(() => _dicts.has(key));
    }

    // Check localStorage cache (TanStack handles this too if configured)
    const cacheKey = `translate:${key}`;
    try {
      const cached = win.localStorage?.getItem(cacheKey);
      if (cached) {
        const { data, ts }: { data: Record<string, any>; ts: number } = JSON.parse(cached);
        // 24h TTL
        if (Date.now() - ts < 86400000) {
          _dicts.set(key, new Map(Object.entries(data)));
          return true;
        }
      }
    } catch {
      // Silent fail
    }

    // Fetch with TanStack if available (prevents bugs like duplicate fetches, adds retries)
    const promise = (async (): Promise<boolean> => {
      try {
        let data: Record<string, any>;
        const path = tone === 'default'
          ? `${_basePath}/${lang}.json`
          : `${_basePath}/${lang}.${tone}.json`;

        if (queryClient) {
          // Use TanStack Query for fetch (caching, retries, stale time = 24h)
          data = await queryClient.fetchQuery({
            queryKey: ['translateDict', key],
            queryFn: async () => {
              const res = await fetch(path);
              if (!res.ok) throw new Error(`HTTP ${res.status}`);
              return res.json();
            },
            staleTime: 86400000, // 24h stale time to match TTL
            cacheTime: Infinity, // Keep in cache forever, but revalidate on stale
            retry: 3, // Auto-retry failed fetches (bug prevention)
          });
        } else {
          // Fallback native fetch
          const res = await fetch(path);
          if (!res.ok) throw new Error(`HTTP ${res.status}`);
          data = await res.json();
        }

        _dicts.set(key, new Map(Object.entries(data)));

        // Cache to localStorage (TanStack also caches, but sync for offline)
        try {
          win.localStorage?.setItem(cacheKey, JSON.stringify({ data, ts: Date.now() }));
        } catch {
          // Silent fail
        }

        return true;
      } catch (e) {
        warn(`Dict fetch failed: ${key}`, e);
        return false;
      } finally {
        _pending.delete(key);
      }
    })();

    _pending.set(key, promise);
    return promise;
  };

  // ═══════════════════════════════════════════════════════════════════════════
  // PERFORMANCE METRICS
  // ═══════════════════════════════════════════════════════════════════════════

  const metric = (name: string, data: any): void => {
    if (!_metricsEnabled) return;

    try {
      // Custom callback first
      if (_metricsCallback) {
        _metricsCallback(name, data);
      }
      // ApolloTrack integration (if available)
      else if ((win as any).ApolloTrack?.event) {
        (win as any).ApolloTrack.event(`translate:${name}`, data);
      }
      // Fallback to Performance API
      else if (win.performance?.mark) {
        win.performance.mark(`translate:${name}`, { detail: data });
      }
    } catch {
      // Silent
    }
  };

  // ═══════════════════════════════════════════════════════════════════════════
  // ERROR HANDLING
  // ═══════════════════════════════════════════════════════════════════════════

  const warn = (msg: string, e?: any): void => {
    if (typeof console !== 'undefined') {
      console.warn?.(`[translate] ${msg}`, e?.message || '');
    }
  };

  const safe = <T extends (...args: any[]) => any>(
    fn: T,
    fallback: any
  ): (...args: Parameters<T>) => ReturnType<T> | any => {
    return function(...args: Parameters<T>): ReturnType<T> | any {
      try {
        return fn.apply(this, args);
      } catch (e) {
        warn('Error', e);
        return typeof fallback === 'function' ? fallback(...args) : fallback;
      }
    };
  };

  // ═══════════════════════════════════════════════════════════════════════════
  // DEBOUNCE (npm-free, optimized)
  // ═══════════════════════════════════════════════════════════════════════════

  const debounce = <T extends (...args: any[]) => any>(fn: T, ms: number): (...args: Parameters<T>) => void => {
    let id: number | undefined;
    return (...args: Parameters<T>): void => {
      if (id !== undefined) clearTimeout(id);
      id = setTimeout(() => fn(...args), ms);
    };
  };

  // ═══════════════════════════════════════════════════════════════════════════
  // DOM TRANSLATION
  // ═══════════════════════════════════════════════════════════════════════════

  /**
   * Translate single element
   */
  const translateEl = (el: Element | null, lang: string, tone: string | undefined): boolean => {
    if (!el || el.getAttribute('data-translated') === 'true') return false;

    const start = _metricsEnabled ? performance.now() : 0;

    const key = el.getAttribute(A.TRANSLATE);
    if (!key) return false;

    // Check locked
    const text = el.textContent || '';
    if (isLocked(text)) {
      el.setAttribute(A.LOCKED, 'true');
      return false;
    }

    // Get tone from element or default
    const elTone = el.getAttribute(A.TONE) || tone || _defaultTone;
    const dictKey = `${lang}:${elTone}`;

    // Try tone-specific, then default
    let dict = _dicts.get(dictKey);
    if (!dict && elTone !== 'default') {
      dict = _dicts.get(`${lang}:default`);
    }
    if (!dict) return false;

    let trans = dict.get(key);
    if (trans === undefined) return false;

    // Handle count/plural
    const countAttr = el.getAttribute(A.COUNT);
    if (countAttr !== null && typeof trans === 'object') {
      const count = parseInt(countAttr, 10);
      if (!isNaN(count)) {
        trans = selectPlural(trans as PluralForms, count, lang);
      }
    }

    // Resolve object/function
    if (typeof trans === 'object') {
      trans = trans.other ?? trans.one ?? String(trans);
    }
    if (typeof trans === 'function') {
      try { trans = trans(); } catch { return false; }
    }
    if (typeof trans !== 'string') return false;

    // Interpolate
    const varsAttr = el.getAttribute(A.VARS);
    if (varsAttr) {
      try {
        trans = interp(trans, JSON.parse(varsAttr));
      } catch {
        // Silent fail
      }
    }
    if (countAttr !== null) {
      trans = interp(trans, { count: parseInt(countAttr, 10) });
    }

    // Skip if same
    if (trans === text) return false;

    // Store original
    if (!el.hasAttribute(A.ORIGINAL)) {
      el.setAttribute(A.ORIGINAL, text);
    }

    // Apply
    el.textContent = trans;
    el.setAttribute(A.TRANSLATED, 'true');

    // Accessibility
    if (el.hasAttribute('aria-label')) {
      el.setAttribute('aria-label', trans);
    }

    if (_metricsEnabled) {
      metric('element', { key, duration: performance.now() - start });
    }

    return true;
  };

  /**
   * Restore single element
   */
  const restoreEl = (el: Element | null): boolean => {
    if (!el || el.getAttribute('data-translated') !== 'true') return false;

    const orig = el.getAttribute(A.ORIGINAL);
    if (orig === null) return false;

    el.textContent = orig;
    el.removeAttribute(A.TRANSLATED);
    el.removeAttribute(A.ORIGINAL);

    return true;
  };

  // ═══════════════════════════════════════════════════════════════════════════
  // SCROLL ORCHESTRATION
  // ═══════════════════════════════════════════════════════════════════════════

  /**
   * Observe scroll/sections with IntersectionObserver for axis lock/gesture handling
   * @param {Element} root - Container to observe
   * @param {Object} opts - { axis: 'x'|'y', lock: true|false, threshold: 0.1, onEnter: fn, onExit: fn }
   */
  const observeScroll = (root: Element | null | undefined, opts: ScrollOptions = {}): () => void => {
    const container = root || getBody();
    if (!container || !hasIntersectionObserver) return () => {};

    if (_scrollObservers.has(container)) return () => {};

    const { axis = 'y', lock = false, threshold = 0.1, onEnter, onExit } = opts;

    // Update global state
    _context.scroll.locked = lock;
    _context.scroll.axis = axis;
    const body = getBody();
    if (body) {
      body.setAttribute(A.SCROLL_LOCK, lock ? 'true' : 'false');
      body.setAttribute(A.SCROLL_AXIS, axis);
    }

    // Prevent default scroll if locked (e.g., for horizontal sections)
    const preventScroll = (e: WheelEvent): void => {
      if (_context.scroll.locked && axis === 'x') {
        if (e.deltaY !== 0) {
          e.preventDefault();
          container.scrollLeft += e.deltaY; // map vertical wheel to horizontal
        }
      }
    };
    if (lock) {
      win.addEventListener('wheel', preventScroll, { passive: false });
    }

    // Observe sections [data-section]
    const observer = new IntersectionObserver((entries: IntersectionObserverEntry[]) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          if (typeof onEnter === 'function') onEnter(entry.target);
        } else {
          if (typeof onExit === 'function') onExit(entry.target);
        }
      });
    }, { root: container, threshold });

    container.querySelectorAll('[data-section]').forEach(sec => observer.observe(sec));

    _scrollObservers.set(container, observer);

    return () => {
      observer.disconnect();
      _scrollObservers.delete(container);
      if (lock) win.removeEventListener('wheel', preventScroll);
    };
  };

  // ═══════════════════════════════════════════════════════════════════════════
  // PUBLIC API
  // ═══════════════════════════════════════════════════════════════════════════

  const API: TranslateAPI = {
    version: '2.2.4',

    // ─────────────────────────────────────────────────────────────────────────
    // CONFIGURATION
    // ─────────────────────────────────────────────────────────────────────────

    config: safe(function(opts: Partial<{ basePath: string; defaultTone: string; metrics: boolean; metricsCallback: (name: string, data: any) => void }> = {}): TranslateAPI {
      if (opts.basePath) _basePath = opts.basePath;
      if (opts.defaultTone) _defaultTone = opts.defaultTone;
      if (opts.metrics !== undefined) _metricsEnabled = opts.metrics;
      if (opts.metricsCallback) _metricsCallback = opts.metricsCallback;
      return this;
    }, function() { return this; }),

    // ─────────────────────────────────────────────────────────────────────────
    // LANGUAGE
    // ─────────────────────────────────────────────────────────────────────────

    get lang(): string {
      if (!_lang) _lang = detectLang();
      return _lang;
    },

    set lang(code: string) {
      const norm = normLang(code);
      const old = _lang;
      _lang = norm;
      _langManual = true;

      const body = getBody();
      if (body) body.dataset.lang = norm;

      if (old !== norm) {
        _listeners.forEach(fn => { try { fn(norm, old!); } catch {} });
      }
    },

    detect: safe(() => detectLang(), _fallback),

    get context(): Readonly<UIContext & { lang: string; languages: string[]; locked: string[]; tones: string[]; basePath: string; defaultTone: string; metricsEnabled: boolean }> {
      return Object.freeze({
        lang: API.lang,
        languages: API.languages,
        locked: API.locked,
        tones: Array.from(new Set(
          Array.from(_dicts.keys()).map(k => k.split(':')[1] || 'default')
        )),
        basePath: _basePath,
        defaultTone: _defaultTone,
        metricsEnabled: _metricsEnabled,
        viewport: { ..._context.viewport },
        input: { ..._context.input },
        scroll: { ..._context.scroll }
      });
    },

    get languages(): string[] {
      const langs = new Set<string>();
      for (const key of _dicts.keys()) {
        langs.add(key.split(':')[0]);
      }
      return Array.from(langs);
    },

    supports: safe((lang: string): boolean => {
      const norm = normLang(lang);
      for (const key of _dicts.keys()) {
        if (key.startsWith(norm + ':')) return true;
      }
      return false;
    }, false),

    onLangChange: safe((fn: (newLang: string, oldLang: string) => void): () => void => {
      if (typeof fn !== 'function') return () => {};
      _listeners.add(fn);
      return () => _listeners.delete(fn);
    }, () => () => {}),

    // ─────────────────────────────────────────────────────────────────────────
    // DICTIONARY MANAGEMENT
    // ─────────────────────────────────────────────────────────────────────────

    register: safe(function(lang: string, translations: Record<string, any>, tone: string = 'default'): TranslateAPI {
      const key = `${normLang(lang)}:${tone}`;

      if (!_dicts.has(key)) {
        _dicts.set(key, new Map<string, any>());
      }

      const dict = _dicts.get(key)!;
      Object.entries(translations).forEach(([k, v]) => dict.set(k, v));

      return this;
    }, function() { return this; }),

    registerAll: safe(function(map: Record<string, Record<string, any>>, tone: string = 'default'): TranslateAPI {
      Object.entries(map).forEach(([lang, trans]) => this.register(lang, trans, tone));
      return this;
    }, function() { return this; }),

    load: safe(async (lang: string, tone: string = 'default'): Promise<boolean> => {
      return fetchDict(normLang(lang), tone);
    }, async () => false),

    preload: safe(async (langs: string | string[], tone: string = 'default'): Promise<void> => {
      const arr = Array.isArray(langs) ? langs : [langs];
      await Promise.all(arr.map(l => fetchDict(normLang(l), tone)));
    }, async () => {}),

    clear: safe((lang: string, tone?: string): boolean => {
      if (tone) {
        return _dicts.delete(`${normLang(lang)}:${tone}`);
      }
      // Clear all tones for lang
      let cleared = false;
      for (const key of _dicts.keys()) {
        if (key.startsWith(normLang(lang) + ':')) {
          _dicts.delete(key);
          cleared = true;
        }
      }
      return cleared;
    }, false),

    clearAll: safe(function(): TranslateAPI {
      _dicts.clear();
      return this;
    }, function() { return this; }),

    reloadDict: safe(async (lang: string, tone: string = _defaultTone): Promise<boolean> => {
      API.clear(lang, tone);
      return API.load(lang, tone);
    }, async () => false),

    // ─────────────────────────────────────────────────────────────────────────
    // LOCKED TERMS
    // ─────────────────────────────────────────────────────────────────────────

    lock: safe(function(...terms: (string | RegExp)[]): TranslateAPI {
      terms.forEach(t => {
        if (t instanceof RegExp) {
          _lockedPatterns.add(t);
        } else if (typeof t === 'string' && t.trim()) {
          _locked.add(t.toLowerCase().trim());
        }
      });
      return this;
    }, function() { return this; }),

    unlock: safe((term: string | RegExp): boolean => {
      if (term instanceof RegExp) {
        _lockedPatterns.delete(term);
        return true;
      }
      return _locked.delete(term.toLowerCase().trim());
    }, false),

    unlockPatterns: safe(function(): TranslateAPI {
      _lockedPatterns.clear();
      return this;
    }, function() { return this; }),

    disableAutoLoanwords: safe(function(): TranslateAPI {
      DEFAULT_LOANWORD_PATTERNS.forEach(p => _lockedPatterns.delete(p));
      return this;
    }, function() { return this; }),

    get locked(): string[] {
      return Array.from(_locked);
    },

    get lockedPatterns(): RegExp[] {
      return Array.from(_lockedPatterns);
    },

    isLocked: safe(isLocked, false),

    // ─────────────────────────────────────────────────────────────────────────
    // TRANSLATION
    // ─────────────────────────────────────────────────────────────────────────

    get: safe((key: string, opts: TranslateOptions = {}): string => {
      const lang = opts.lang ? normLang(opts.lang) : API.lang;
      const tone = opts.tone || _defaultTone;
      const dictKey = `${lang}:${tone}`;

      let dict = _dicts.get(dictKey);
      if (!dict && tone !== 'default') {
        dict = _dicts.get(`${lang}:default`);
      }

      if (!dict) return opts.fallback ?? key;

      let trans = dict.get(key);
      if (trans === undefined) return opts.fallback ?? key;

      // Plural
      if (typeof opts.count === 'number' && typeof trans === 'object') {
        trans = selectPlural(trans as PluralForms, opts.count, lang);
      }

      // Resolve
      if (typeof trans === 'function') trans = trans(opts);
      if (typeof trans === 'object') trans = trans.other ?? trans.one ?? String(trans);

      trans = String(trans);

      // Interpolate
      if (opts.vars) trans = interp(trans, opts.vars);
      if (typeof opts.count === 'number') trans = interp(trans, { count: opts.count });

      return trans;
    }, (key: string) => key),

    getAsync: safe(async (key: string, opts: TranslateOptions = {}): Promise<string> => {
      const lang = opts.lang ? normLang(opts.lang) : API.lang;
      const tone = opts.tone || _defaultTone;

      // Try load if not present
      if (!_dicts.has(`${lang}:${tone}`)) {
        await fetchDict(lang, tone);
      }

      return API.get(key, opts);
    }, async (key: string) => key),

    has: safe((key: string, lang?: string, tone?: string): boolean => {
      const l = lang ? normLang(lang) : API.lang;
      const t = tone || _defaultTone;
      const dict = _dicts.get(`${l}:${t}`);
      return dict ? dict.has(key) : false;
    }, false),

    // ─────────────────────────────────────────────────────────────────────────
    // DOM
    // ─────────────────────────────────────────────────────────────────────────

    apply: safe((root?: Element, lang?: string, tone?: string): number => {
      const container = root || getBody();
      if (!container) return 0;

      const start = _metricsEnabled ? performance.now() : 0;

      const targetLang = lang ? normLang(lang) : API.lang;
      const contextLang = container.closest?.(`[${A.LANG}]`)?.getAttribute(A.LANG) ?? null;
      const finalLang = contextLang ? normLang(contextLang) : targetLang;

      const els = container.querySelectorAll(`[${A.TRANSLATE}]:not([${A.TRANSLATED}="true"])`);
      let count = 0;

      els.forEach(el => {
        if (translateEl(el as Element, finalLang, tone)) count++;
      });

      if (_metricsEnabled) {
        metric('apply', { count, duration: performance.now() - start });
      }

      return count;
    }, 0),

    applyAsync: safe(async (root?: Element, lang?: string, tone?: string): Promise<number> => {
      const targetLang = lang ? normLang(lang) : API.lang;
      await fetchDict(targetLang, tone || _defaultTone);
      return API.apply(root, lang, tone);
    }, async () => 0),

    restore: safe((root?: Element): number => {
      const container = root || getBody();
      if (!container) return 0;

      const els = container.querySelectorAll(`[${A.TRANSLATED}="true"]`);
      let count = 0;

      els.forEach(el => { if (restoreEl(el as Element)) count++; });

      return count;
    }, 0),

    retranslate: safe((root?: Element, lang?: string, tone?: string): number => {
      API.restore(root);
      return API.apply(root, lang, tone);
    }, 0),

    // ─────────────────────────────────────────────────────────────────────────
    // OBSERVATION
    // ─────────────────────────────────────────────────────────────────────────

    observe: safe((root?: Element, opts: ObserveOptions = {}): () => void => {
      const container = root || getBody();
      if (!container || !hasMutationObserver) return () => {};

      if (_observers.has(container)) {
        return () => {
          _observers.get(container)?.disconnect();
          _observers.delete(container);
        };
      }

      const { immediate = true, lang, tone } = opts;

      if (immediate) {
        API.apply(container, lang, tone);
      }

      // Debounced apply using idle callback
      const debouncedApply = debounce(() => {
        rIC(() => API.apply(container, lang || API.lang, tone));
      }, 100);

      const observer = new MutationObserver((mutations: MutationRecord[]) => {
        let shouldTranslate = false;

        for (const m of mutations) {
          for (const n of m.addedNodes) {
            if (n.nodeType === 1) {
              if ((n as Element).hasAttribute?.(A.TRANSLATE) || (n as Element).querySelector?.(`[${A.TRANSLATE}]`)) {
                shouldTranslate = true;
                break;
              }
            }
          }
          if (shouldTranslate) break;
        }

        if (shouldTranslate) debouncedApply();
      });

      observer.observe(container, { childList: true, subtree: true });
      _observers.set(container, observer);

      return () => {
        observer.disconnect();
        _observers.delete(container);
      };
    }, () => () => {}),

    unobserve: safe((root?: Element): boolean => {
      const container = root || getBody();
      if (!container) return false;

      const obs = _observers.get(container);
      if (!obs) return false;

      obs.disconnect();
      _observers.delete(container);
      return true;
    }, false),

    unobserveAll: safe((): number => {
      const count = _observers.size;
      _observers.forEach(o => o.disconnect());
      _observers.clear();
      return count;
    }, 0),

    // ─────────────────────────────────────────────────────────────────────────
    // SCROLL & CONTEXT
    // ─────────────────────────────────────────────────────────────────────────

    observeScroll: safe(observeScroll, () => () => {}),

    unobserveScroll: safe((root?: Element): boolean => {
      const container = root || getBody();
      if (!container) return false;

      const obs = _scrollObservers.get(container);
      if (!obs) return false;

      obs.disconnect();
      _scrollObservers.delete(container);
      return true;
    }, false),

    detectContext: safe(detectContext, () => {}),

    observeContext: safe(observeContext, () => () => {}),

    stopObserveContext: safe((): boolean => {
      if (_resizeHandler) {
        win.removeEventListener('resize', _resizeHandler);
        _resizeHandler = null;
        return true;
      }
      return false;
    }, false),

    // ─────────────────────────────────────────────────────────────────────────
    // UTILITIES
    // ─────────────────────────────────────────────────────────────────────────

    interp: safe(interp, (s: string) => s),

    plural: safe((forms: PluralForms | string, count: number, lang?: string): string => selectPlural(forms, count, lang || API.lang), ''),

    scope: safe((namespace: string, tone?: string): { get: (key: string, opts?: TranslateOptions) => string; has: (key: string, lang?: string) => boolean; tone: string } => {
      const prefix = namespace.endsWith('.') ? namespace : `${namespace}.`;
      const t = tone || _defaultTone;

      return Object.freeze({
        get: (key: string, opts: TranslateOptions = {}): string => API.get(`${prefix}${key}`, { ...opts, tone: t }),
        has: (key: string, lang?: string): boolean => API.has(`${prefix}${key}`, lang, t),
        tone: t
      });
    }, { get: (k: string) => k, has: () => false, tone: 'default' }),

    tone: safe((toneName: string): { get: (key: string, opts?: TranslateOptions) => string; has: (key: string, lang?: string) => boolean; apply: (root?: Element, lang?: string) => number; scope: (ns: string) => any } => {
      return Object.freeze({
        get: (key: string, opts: TranslateOptions = {}): string => API.get(key, { ...opts, tone: toneName }),
        has: (key: string, lang?: string): boolean => API.has(key, lang, toneName),
        apply: (root?: Element, lang?: string): number => API.apply(root, lang, toneName),
        scope: (ns: string): any => API.scope(ns, toneName)
      });
    }, { get: (k: string) => k, has: () => false, apply: () => 0, scope: () => ({}) }),

    export: safe((): Record<string, Record<string, any>> => {
      const result: Record<string, Record<string, any>> = {};
      _dicts.forEach((dict, key) => {
        result[key] = Object.fromEntries(dict);
      });
      return result;
    }, {}),

    import: safe(function(data: Record<string, Record<string, any>>): TranslateAPI {
      Object.entries(data).forEach(([key, trans]) => {
        const [lang, tone = 'default'] = key.split(':');
        this.register(lang, trans, tone);
      });
      return this;
    }, function() { return this; }),

    ATTR: A
  };

  // ═══════════════════════════════════════════════════════════════════════════
  // INITIALIZATION
  // ═══════════════════════════════════════════════════════════════════════════
  // Note: When loaded via Apollo CDN, initialization is handled by the loader.
  // This section only runs for standalone usage without Apollo.
  if (doc) {
    const init = (): void => {
      const body = getBody();
      // Standalone auto-init (only if Apollo is NOT present)
      if (body?.dataset?.translateAuto !== undefined && !(win as any).Apollo) {
        rIC(() => {
          API.detectContext();
          API.observe();
        });
      }
    };

    if (doc.readyState === 'loading') {
      doc.addEventListener('DOMContentLoaded', init, { once: true });
    } else {
      init();
    }
  }

  return Object.freeze(API);
});