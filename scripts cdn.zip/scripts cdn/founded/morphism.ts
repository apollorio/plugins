/**
 * Apollo Morphism - SVG Icon Morphing System
 * @version 2.0.0
 * @description Optimized icon morphing with conditional GSAP loading
 * 
 * Usage: Place <i class="apollo"></i> in your HTML
 * The script auto-detects apollo icons and enables morphing when found.
 * 
 * CDN Integration: https://cdn.apollo.rio.br/ts/morphism.ts
 */

// ============================================================================
// TYPE DECLARATIONS
// ============================================================================

declare global {
  interface Window {
    gsap: GSAPStatic | undefined;
    MorphSVGPlugin: MorphSVGPluginStatic | undefined;
    apolloMorphism: string;
  }
}

interface GSAPStatic {
  registerPlugin: (plugin: unknown) => void;
  timeline: (config?: GSAPTimelineConfig) => GSAPTimeline;
  to: (target: string | Element, config: GSAPTweenConfig) => GSAPTween;
}

interface GSAPTimeline {
  to: (target: string | Element, config: GSAPTweenConfig) => GSAPTimeline;
  timeScale: (value: number) => GSAPTimeline;
}

interface GSAPTween {
  kill: () => void;
}

interface GSAPTimelineConfig {
  repeat?: number;
  yoyo?: boolean;
}

interface GSAPTweenConfig {
  morphSVG?: { shape: string; type: string };
  rotation?: number;
  duration?: number;
  ease?: string;
  transformOrigin?: string;
}

interface MorphSVGPluginStatic {
  // Plugin interface
}

// ============================================================================
// CONSTANTS
// ============================================================================

const CDN_BASE = 'https://assets.apollo.rio.br/js/' as const;
const VERSION = '2.0.0' as const;
const SELECTOR_APOLLO = 'i.apollo' as const;

// Shape paths for morphing animation
const SHAPES = {
  shape1: 'M 26.806 41.798 L 36.345 41.798 C 45.568 41.798 50.476 44.109 56.725 50.221 C 57.075 50.561 57.12 51.111 56.793 51.467 L 48.828 60.104 C 48.502 60.461 47.912 60.525 47.582 60.168 L 37.232 49.099 L 37.232 63.691 C 37.232 64.175 36.836 64.572 36.348 64.572 L 26.814 64.572 C 26.326 64.572 25.928 64.175 25.928 63.691 L 25.928 42.682 C 25.928 42.195 26.326 41.798 26.814 41.798 L 26.806 41.798 Z M 23.275 26.789 L 23.275 36.327 C 23.275 45.551 20.964 50.458 14.852 56.707 C 14.512 57.054 13.961 57.102 13.605 56.775 L 4.968 48.811 C 4.612 48.48 4.547 47.894 4.904 47.563 L 15.977 37.215 L 1.381 37.215 C 0.898 37.215 0.5 36.817 0.5 36.33 L 0.5 26.795 C 0.5 26.308 0.898 25.911 1.381 25.911 L 22.391 25.911 C 22.877 25.911 23.275 26.308 23.275 26.795 L 23.275 26.789 Z M 38.291 23.302 L 28.755 23.302 C 19.529 23.302 14.621 20.991 8.371 14.879 C 8.025 14.539 7.977 13.988 8.307 13.632 L 16.269 4.995 C 16.598 4.639 17.185 4.574 17.519 4.931 L 27.865 16.001 L 27.865 1.408 C 27.865 0.925 28.261 0.527 28.749 0.527 L 38.287 0.527 C 38.771 0.527 39.169 0.925 39.169 1.408 L 39.169 22.418 C 39.169 22.904 38.771 23.302 38.287 23.302 L 38.291 23.302 Z M 41.825 38.26 L 41.825 28.725 C 41.825 19.498 44.133 14.59 50.245 8.341 C 50.584 7.995 51.139 7.946 51.495 8.277 L 60.129 16.241 C 60.484 16.568 60.548 17.157 60.196 17.488 L 49.123 27.837 L 63.716 27.837 C 64.202 27.837 64.6 28.234 64.6 28.718 L 64.6 38.256 C 64.6 38.74 64.202 39.138 63.716 39.138 L 42.706 39.138 C 42.223 39.138 41.825 38.74 41.825 38.256 L 41.825 38.26 Z',
  shape2: 'M2 32.2114V32.2114C2 15.7598 15.3368 2.42304 31.7884 2.42304V2.42304V2.42304C48.2401 2.42303 61.5768 15.7598 61.5768 32.2114V32.2114V32.2114C61.5768 48.663 48.24 61.9998 31.7884 61.9998V61.9998V61.9998C15.3369 61.9998 2 48.6629 2 32.2114V32.2114ZM61.7888 32.1274V32.1274C61.7888 48.579 48.4521 61.9158 32.0004 61.9158V61.9158V61.9158C15.5488 61.9158 2.21209 48.5791 2.21209 32.1274V32.1274V32.1274C2.21209 15.6758 15.5488 2.33907 32.0005 2.33907V2.33907V2.33907C48.4521 2.33908 61.7888 15.6758 61.7888 32.1274V32.1274Z',
  shape3: 'M16.9999 62C8.7158 62 2.00019 55.2842 2.00012 47.0001V47.0001C2.00005 38.7159 8.71571 32 16.9999 32V32V32C25.2842 32 32 38.7157 32 47V47C32 55.2842 25.2842 62 16.9999 62V62V62ZM46.9999 62C38.7158 62 32.0002 55.2842 32.0001 47.0001V47.0001C32.0001 38.7159 38.7157 32 46.9999 32V32V32C55.2842 32 62 38.7157 62 47V47C62 55.2842 55.2842 62 46.9999 62V62V62ZM16.9999 32C8.7158 32 2.00019 25.2842 2.00012 17.0001V17.0001C2.00005 8.71588 8.71571 2 16.9999 2V2V2C25.2842 2 32 8.71573 32 17V17C32 25.2842 25.2842 32 16.9999 32V32V32ZM46.9999 32C38.7158 32 32.0002 25.2842 32.0001 17.0001V17.0001C32.0001 8.71588 38.7157 2 46.9999 2V2V2C55.2842 2 62 8.71573 62 17V17C62 25.2842 55.2842 32 46.9999 32V32V32Z',
  shape4: 'M 3 34.913 L 16.247 34.913 C 16.768 44.441 22.55 53.29 27.49 60.797 C 14.477 58.774 4.314 48.146 3 34.913 Z M 3 29.085 C 4.314 15.853 14.477 5.225 27.49 3.202 C 22.55 10.707 16.768 19.558 16.247 29.085 L 3 29.085 Z M 61 29.085 L 47.753 29.085 C 47.232 19.558 41.45 10.707 36.513 3.202 C 49.523 5.225 59.689 15.853 61 29.085 Z M 61 34.913 C 59.689 48.146 49.523 58.774 36.513 60.797 C 41.45 53.29 47.232 44.441 47.753 34.913 L 61 34.913 Z M 22.087 34.913 L 41.916 34.913 C 41.415 43.024 36.123 50.574 32.002 57.037 C 27.877 50.574 22.585 43.024 22.087 34.913 Z M 22.087 29.085 C 22.585 20.974 27.877 13.425 32.002 6.958 C 36.123 13.425 41.415 20.974 41.916 29.085 L 22.087 29.085 Z',
  shape5: 'M2.00093 62C1.99812 62 2.00048 62.0003 2.00048 61.9974V61.9974C2.00047 45.4319 15.4341 32.0001 31.9997 32.0001V32.0001V32.0001C48.5653 32.0001 61.9997 45.4318 61.9997 61.9974V61.9974C61.9997 62.0002 62.002 61.9999 61.9992 61.9999C61.8892 61.9999 41.8245 62 31.9997 62C22.1749 62 2.11091 62 2.00093 62ZM62 31.9975C62 32.0003 62.0024 32 61.9995 32C61.8896 32 41.8246 32 31.9999 32C22.1545 32 2.026 32 2.00002 32C1.99936 32 2 32.0001 2 31.9994V31.9994C2 15.4315 15.432 2.00004 31.9999 2.0001V2.0001V2.0001C48.5656 2.00013 62 15.4318 62 31.9975V31.9975Z',
  shape6: 'M2 32.2114V32.2114C2 15.7598 15.3368 2.42304 31.7884 2.42304V2.42304V2.42304C48.2401 2.42303 61.5768 15.7598 61.5768 32.2114V32.2114C61.5768 39.2713 61.5768 51.6559 61.5768 58.0025C61.5768 60.2116 59.7889 61.9995 57.5798 61.9995C51.2331 61.9996 38.8483 61.9998 31.7884 61.9998C24.7286 61.9998 12.3441 61.9999 5.99746 62C3.78835 62 2.00043 60.2121 2.00039 58.003C2.00025 51.6563 2 39.2713 2 32.2114ZM61.7888 32.1274C61.7888 39.1873 61.7889 51.572 61.789 57.9187C61.789 60.1279 60.0011 61.9158 57.792 61.9158C51.4452 61.9158 39.0603 61.9158 32.0004 61.9158C24.9406 61.9158 12.5558 61.9158 6.20912 61.9158C3.99998 61.9158 2.21209 60.1279 2.21209 57.9188C2.21209 51.5721 2.21209 39.1873 2.21209 32.1274V32.1274C2.21209 15.6758 15.5488 2.33907 32.0005 2.33907V2.33907V2.33907C48.4521 2.33908 61.7888 15.6758 61.7888 32.1274V32.1274Z',
  shape7: 'M31.7884 2L34.6588 15.2382C36.1434 22.0852 41.4916 27.4333 48.3385 28.918L61.5767 31.7884L48.3386 34.6588C41.4916 36.1434 36.1434 41.4916 34.6588 48.3385L31.7884 61.5767L28.918 48.3386C27.4333 41.4916 22.0852 36.1434 15.2382 34.6588L2 31.7884L15.2382 28.918C22.0852 27.4333 27.4333 22.0852 28.918 15.2382L31.7884 2ZM31.7884 2.00001L34.6588 15.2382C36.1434 22.0852 41.4916 27.4334 48.3385 28.918L61.5767 31.7884L48.3385 34.6588C41.4916 36.1434 36.1434 41.4916 34.6588 48.3386L31.7884 61.5767L28.918 48.3386C27.4333 41.4916 22.0852 36.1434 15.2382 34.6588L1.99999 31.7884L15.2382 28.918C22.0852 27.4334 27.4333 22.0852 28.918 15.2382L31.7884 2.00001Z',
  shape8: 'M62 31.7884L48.7618 34.6588C41.9148 36.1434 36.5667 41.4916 35.082 48.3385L32.2116 61.5767L29.3412 48.3385C27.8566 41.4916 22.5084 36.1434 15.6615 34.6588L2.42327 31.7884L15.6614 28.918C22.5084 27.4333 27.8566 22.0852 29.3412 15.2382L32.2116 2L35.082 15.2382C36.5667 22.0852 41.9148 27.4333 48.7618 28.918L62 31.7884ZM11.0636 10.9364L22.454 18.2676C28.3454 22.0593 35.9088 22.0593 41.8002 18.2676L53.1907 10.9364L45.8595 22.3269C42.0678 28.2183 42.0678 35.7817 45.8595 41.6731L53.1907 53.0636L41.8002 45.7324C35.9088 41.9407 28.3454 41.9407 22.454 45.7324L11.0636 53.0636L18.3947 41.6731C22.1864 35.7817 22.1865 28.2183 18.3947 22.3269L11.0636 10.9364Z',
} as const;

// ============================================================================
// SVG TEMPLATE FACTORY
// ============================================================================

/**
 * Creates SVG markup with all morphable shapes
 * @param animated - Whether to include animation paths (hidden by default)
 */
function createSvgTemplate(animated: boolean): string {
  const baseStyle = 'display:inline-block!important;width:22px;align-items:center;text-align:center;margin:6px 6px -5px 0';
  const hiddenStyle = 'opacity:0';
  
  const shapePaths = animated ? `
    <path id="shape1" d="${SHAPES.shape1}" fill="currentColor" stroke="currentColor" stroke-width="2"/>
    <path id="shape2" d="${SHAPES.shape2}" fill="currentColor" stroke="currentColor" stroke-width="2" style="${hiddenStyle}"/>
    <path id="shape3" d="${SHAPES.shape3}" fill="currentColor" stroke="currentColor" stroke-width="2" style="${hiddenStyle}"/>
    <path id="shape4" d="${SHAPES.shape4}" fill="currentColor" stroke="currentColor" stroke-width="0" style="${hiddenStyle}"/>
    <path id="shape5" d="${SHAPES.shape5}" fill="currentColor" stroke="currentColor" stroke-width="2" style="${hiddenStyle}"/>
    <path id="shape6" d="${SHAPES.shape6}" fill="currentColor" stroke="currentColor" stroke-width="2" style="${hiddenStyle}"/>
    <path id="shape7" d="${SHAPES.shape7}" fill="currentColor" stroke="currentColor" stroke-width="2" style="${hiddenStyle}"/>
    <path id="shape8" d="${SHAPES.shape8}" fill="currentColor" stroke="currentColor" stroke-width="2" style="${hiddenStyle}"/>
  ` : `
    <path id="shape1" d="${SHAPES.shape1}" fill="currentColor" stroke="currentColor" stroke-width="2"/>
  `;

  return `<svg id="logo-svg" viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg" style="${baseStyle}">${shapePaths}</svg>`;
}

// ============================================================================
// STATE MANAGEMENT
// ============================================================================

/** Tracks processed elements to prevent double-initialization */
const processedElements = new WeakSet<Element>();

/** Tracks if morphing animation is active */
let morphingActive = false;

/** MutationObserver instance */
let domObserver: MutationObserver | null = null;

// ============================================================================
// SCRIPT LOADER
// ============================================================================

/**
 * Dynamically loads an external script with caching
 * @param name - Global variable name to check/set
 * @param url - Script URL to load
 */
async function loadScript(name: string, url: string): Promise<void> {
  // Skip if already loaded
  if ((window as Record<string, unknown>)[name]) {
    return;
  }

  return new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = url;
    script.defer = true;
    
    // Use high fetch priority for critical animation scripts
    if ('fetchPriority' in script) {
      (script as HTMLScriptElement & { fetchPriority: string }).fetchPriority = 'high';
    }
    
    script.onload = () => resolve();
    script.onerror = () => reject(new Error(`Failed to load: ${name} from ${url}`));
    
    document.head.appendChild(script);
  });
}

/**
 * Loads GSAP and MorphSVGPlugin dependencies
 */
async function loadMorphingDependencies(): Promise<boolean> {
  try {
    await loadScript('gsap', `${CDN_BASE}gsap.min.js`);
    await loadScript('MorphSVGPlugin', `${CDN_BASE}gsap-svg-morphism.min.js`);
    return true;
  } catch (error) {
    console.error('[Apollo Morphism] Dependency load failed:', error);
    return false;
  }
}

// ============================================================================
// ICON REPLACEMENT
// ============================================================================

/**
 * Replaces <i class="apollo"> elements with SVG icons
 * @param animated - Whether to use animated SVG template
 */
function replaceApolloIcons(animated: boolean): void {
  const svgTemplate = createSvgTemplate(animated);
  
  document.querySelectorAll<HTMLElement>(SELECTOR_APOLLO).forEach((element) => {
    // Skip already processed elements
    if (processedElements.has(element)) {
      return;
    }
    
    processedElements.add(element);
    
    // Create wrapper and insert SVG
    const wrapper = document.createElement('span');
    wrapper.innerHTML = svgTemplate;
    wrapper.className = 'apollo-logo-wrapper';
    
    // Preserve any data attributes from original element
    Array.from(element.dataset).forEach(([key, value]) => {
      if (value) wrapper.dataset[key] = value;
    });
    
    element.replaceWith(wrapper);
  });
}

// ============================================================================
// MORPHING ANIMATION
// ============================================================================

/**
 * Initializes the SVG morphing animation
 * Requires GSAP and MorphSVGPlugin to be loaded
 */
function initializeMorphingAnimation(): void {
  const { gsap, MorphSVGPlugin } = window;
  
  // Validate dependencies
  if (!gsap || !MorphSVGPlugin) {
    return;
  }
  
  // Register plugin
  gsap.registerPlugin(MorphSVGPlugin);
  
  // Find primary shape
  const primaryShape = document.querySelector<SVGPathElement>('#shape1');
  
  if (!primaryShape || primaryShape.dataset.animated) {
    return;
  }
  
  // Mark as animated to prevent re-initialization
  primaryShape.dataset.animated = 'true';
  morphingActive = true;
  
  // Create morphing timeline
  const morphTimeline = gsap.timeline({ repeat: -1, yoyo: true });
  
  // Target shapes for morphing sequence
  const targetShapes = ['#shape2', '#shape3', '#shape4', '#shape5', '#shape6', '#shape7', '#shape8'];
  
  // Add morphing transitions
  targetShapes.forEach((shape) => {
    morphTimeline.to('#shape1', {
      morphSVG: { shape, type: 'rotational' },
      duration: 3.2,
      ease: 'sine.inOut',
    });
  });
  
  // Adjust playback speed
  morphTimeline.timeScale(0.7);
  
  // Optional: Animate logo letter 'e' if present
  const letterE = document.getElementById('logo-letter-e');
  if (letterE) {
    gsap.timeline({ repeat: -1, yoyo: true })
      .to(letterE, {
        rotation: 9,
        duration: 2.8,
        ease: 'sine.inOut',
        transformOrigin: 'center center',
      })
      .to(letterE, {
        rotation: -8,
        duration: 2.6,
        ease: 'sine.inOut',
      })
      .to(letterE, {
        rotation: 0,
        duration: 3.2,
        ease: 'sine.out',
      });
  }
}

// ============================================================================
// DOM OBSERVATION
// ============================================================================

/**
 * Sets up MutationObserver to handle dynamically added elements
 * @param animated - Whether new icons should be animated
 */
function observeDomChanges(animated: boolean): void {
  if (domObserver) {
    return; // Already observing
  }
  
  domObserver = new MutationObserver((mutations) => {
    let needsProcessing = false;
    
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType !== Node.ELEMENT_NODE) {
          continue;
        }
        
        const element = node as Element;
        
        // Check if the added node itself is an apollo icon
        if (element.matches?.(SELECTOR_APOLLO)) {
          needsProcessing = true;
          break;
        }
        
        // Check if any descendants are apollo icons
        if (element.querySelectorAll?.(SELECTOR_APOLLO).length > 0) {
          needsProcessing = true;
          break;
        }
      }
      
      if (needsProcessing) {
        break;
      }
    }
    
    if (needsProcessing) {
      replaceApolloIcons(animated);
      
      // Re-initialize animation if morphing is active but new icons were added
      if (animated && morphingActive) {
        requestAnimationFrame(initializeMorphingAnimation);
      }
    }
  });
  
  domObserver.observe(document.body, {
    childList: true,
    subtree: true,
  });
}

// ============================================================================
// DETECTION & INITIALIZATION
// ============================================================================

/**
 * Checks if any apollo icons exist in the document
 */
function hasApolloIcons(): boolean {
  return document.querySelector(SELECTOR_APOLLO) !== null;
}

/**
 * Main initialization - conditionally loads morphing based on icon presence
 */
async function initialize(): Promise<void> {
  const apolloIconsExist = hasApolloIcons();
  
  if (apolloIconsExist) {
    // APOLLO ICONS FOUND: Load full morphing system
    try {
      const depsLoaded = await loadMorphingDependencies();
      
      // Replace icons with animated SVG
      replaceApolloIcons(true);
      
      // Initialize morphing animation
      if (depsLoaded) {
        requestAnimationFrame(initializeMorphingAnimation);
      }
      
      // Watch for dynamically added icons
      observeDomChanges(true);
      
    } catch (error) {
      console.error('[Apollo Morphism] Initialization failed:', error);
      // Fallback: Show static icons
      replaceApolloIcons(false);
      observeDomChanges(false);
    }
  } else {
    // NO APOLLO ICONS: Set up lightweight observer for future icons
    // This is the "fallback" mode - no scripts loaded until needed
    
    const lazyObserver = new MutationObserver((mutations) => {
      for (const mutation of mutations) {
        for (const node of mutation.addedNodes) {
          if (node.nodeType !== Node.ELEMENT_NODE) continue;
          
          const element = node as Element;
          const hasApollo = element.matches?.(SELECTOR_APOLLO) || 
                           element.querySelector?.(SELECTOR_APOLLO);
          
          if (hasApollo) {
            // Icons appeared! Initialize full system
            lazyObserver.disconnect();
            initialize();
            return;
          }
        }
      }
    });
    
    lazyObserver.observe(document.body, {
      childList: true,
      subtree: true,
    });
  }
}

// ============================================================================
// PUBLIC API
// ============================================================================

/**
 * Manually trigger icon replacement
 * Useful when icons are added programmatically
 */
export function refreshApolloIcons(): void {
  replaceApolloIcons(morphingActive);
}

/**
 * Check if morphing animation is currently active
 */
export function isMorphingActive(): boolean {
  return morphingActive;
}

/**
 * Get current version
 */
export function getVersion(): string {
  return VERSION;
}

// ============================================================================
// AUTO-INITIALIZATION
// ============================================================================

// Run on DOM ready or immediately if already loaded
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initialize);
} else {
  initialize();
}

// Expose version globally
window.apolloMorphism = VERSION;

// Default export for ES modules
export default {
  refresh: refreshApolloIcons,
  isMorphingActive,
  version: VERSION,
};