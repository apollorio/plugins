/**
 * Apollo Popper Manager - Modern TypeScript Edition (2026)
 * 
 * A comprehensive, type-safe wrapper for Popper.js v1.x providing tooltip,
 * popover, and dropdown positioning with modern TypeScript features.
 * 
 * @module ApolloPopper
 * @version 3.0.0
 * @license MIT
 */

// ============================================================================
// Type Definitions
// ============================================================================

/**
 * Popper.js placement options
 */
type PopperPlacement =
  | 'auto'
  | 'auto-start'
  | 'auto-end'
  | 'top'
  | 'top-start'
  | 'top-end'
  | 'right'
  | 'right-start'
  | 'right-end'
  | 'bottom'
  | 'bottom-start'
  | 'bottom-end'
  | 'left'
  | 'left-start'
  | 'left-end';

/**
 * Boundary element options
 */
type BoundaryElement = 'scrollParent' | 'viewport' | 'window' | HTMLElement;

/**
 * Popper modifier configuration
 */
interface PopperModifier {
  enabled?: boolean;
  order?: number;
  fn?: (data: PopperData, options: any) => PopperData;
}

/**
 * Offset modifier options
 */
interface OffsetModifier extends PopperModifier {
  offset?: number | string;
}

/**
 * Prevent overflow modifier options
 */
interface PreventOverflowModifier extends PopperModifier {
  boundariesElement?: BoundaryElement;
  padding?: number;
  priority?: Array<'left' | 'right' | 'top' | 'bottom'>;
  escapeWithReference?: boolean;
}

/**
 * Flip modifier options
 */
interface FlipModifier extends PopperModifier {
  behavior?: 'flip' | 'clockwise' | 'counterclockwise' | PopperPlacement[];
  boundariesElement?: BoundaryElement;
  padding?: number;
  flipVariations?: boolean;
}

/**
 * Arrow modifier options
 */
interface ArrowModifier extends PopperModifier {
  element?: string | HTMLElement;
}

/**
 * All modifier options
 */
interface PopperModifiers {
  shift?: PopperModifier;
  offset?: OffsetModifier;
  preventOverflow?: PreventOverflowModifier;
  keepTogether?: PopperModifier;
  arrow?: ArrowModifier;
  flip?: FlipModifier;
  inner?: PopperModifier;
  hide?: PopperModifier;
  computeStyle?: PopperModifier & {
    gpuAcceleration?: boolean;
    x?: 'bottom' | 'top';
    y?: 'left' | 'right';
  };
  applyStyle?: PopperModifier;
}

/**
 * Offsets for reference and popper elements
 */
interface Offsets {
  top: number;
  left: number;
  width: number;
  height: number;
  right?: number;
  bottom?: number;
  position?: 'absolute' | 'fixed';
}

/**
 * Data passed to modifier functions
 */
interface PopperData {
  instance: PopperInstance;
  placement: PopperPlacement;
  originalPlacement: PopperPlacement;
  flipped: boolean;
  hide: boolean;
  arrowElement: HTMLElement | null;
  styles: Partial<CSSStyleDeclaration>;
  arrowStyles: Partial<CSSStyleDeclaration>;
  boundaries: Offsets;
  offsets: {
    popper: Offsets;
    reference: Offsets;
    arrow?: Offsets;
  };
  attributes?: Record<string, string | boolean>;
}

/**
 * Popper.js configuration options
 */
interface PopperOptions {
  placement?: PopperPlacement;
  positionFixed?: boolean;
  eventsEnabled?: boolean;
  removeOnDestroy?: boolean;
  modifiers?: PopperModifiers;
  onCreate?: (data: PopperData) => void;
  onUpdate?: (data: PopperData) => void;
}

/**
 * Popper instance interface
 */
interface PopperInstance {
  update(): void;
  destroy(): void;
  enableEventListeners(): void;
  disableEventListeners(): void;
  scheduleUpdate(): void;
  options: Required<PopperOptions>;
  popper: HTMLElement;
  reference: HTMLElement;
}

/**
 * Popper constructor interface
 */
interface PopperConstructor {
  new (
    reference: HTMLElement,
    popper: HTMLElement,
    options?: PopperOptions
  ): PopperInstance;
  Defaults: Required<PopperOptions>;
  placements: PopperPlacement[];
}

// ============================================================================
// Global Window Extension
// ============================================================================

declare global {
  interface Window {
    Popper?: PopperConstructor;
    ApolloPopper?: ApolloPopperAPI;
  }
}

// ============================================================================
// Apollo Popper Manager
// ============================================================================

/**
 * Public API interface
 */
interface ApolloPopperAPI {
  create: (
    reference: HTMLElement | string,
    popper: HTMLElement | string,
    options?: PopperOptions
  ) => PopperInstance | null;
  createTooltip: (
    element: HTMLElement | string,
    content: string,
    options?: Partial<TooltipOptions>
  ) => PopperInstance | null;
  createDropdown: (
    trigger: HTMLElement | string,
    menu: HTMLElement | string,
    options?: Partial<DropdownOptions>
  ) => PopperInstance | null;
  destroy: (instance: PopperInstance) => void;
  destroyAll: () => void;
  version: string;
}

/**
 * Tooltip configuration options
 */
interface TooltipOptions {
  placement: PopperPlacement;
  offset: number;
  trigger: 'hover' | 'click' | 'focus' | 'manual';
  delay: number;
  hideDelay: number;
  className: string;
  arrow: boolean;
}

/**
 * Dropdown configuration options
 */
interface DropdownOptions {
  placement: PopperPlacement;
  offset: number;
  trigger: 'click' | 'hover' | 'manual';
  closeOnClickOutside: boolean;
  className: string;
}

// ============================================================================
// Implementation
// ============================================================================

class ApolloPopperManager {
  private instances: Set<PopperInstance> = new Set();
  private readonly version = '3.0.0';

  /**
   * Gets an element by selector or returns the element itself
   */
  private getElement(elementOrSelector: HTMLElement | string): HTMLElement | null {
    if (typeof elementOrSelector === 'string') {
      return document.querySelector<HTMLElement>(elementOrSelector);
    }
    return elementOrSelector;
  }

  /**
   * Checks if Popper.js is available
   */
  private isPopperAvailable(): boolean {
    if (!window.Popper) {
      console.error('[ApolloPopper] Popper.js library not found. Please include Popper.js before using ApolloPopper.');
      return false;
    }
    return true;
  }

  /**
   * Creates a new Popper instance
   */
  public create(
    reference: HTMLElement | string,
    popper: HTMLElement | string,
    options: PopperOptions = {}
  ): PopperInstance | null {
    if (!this.isPopperAvailable()) {
      return null;
    }

    const refElement = this.getElement(reference);
    const popperElement = this.getElement(popper);

    if (!refElement || !popperElement) {
      console.error('[ApolloPopper] Reference or popper element not found');
      return null;
    }

    const defaultOptions: PopperOptions = {
      placement: 'bottom',
      modifiers: {
        preventOverflow: {
          boundariesElement: 'viewport',
        },
      },
    };

    const mergedOptions = this.mergeOptions(defaultOptions, options);
    const instance = new window.Popper!(refElement, popperElement, mergedOptions);

    this.instances.add(instance);
    return instance;
  }

  /**
   * Creates a tooltip with predefined styling and behavior
   */
  public createTooltip(
    element: HTMLElement | string,
    content: string,
    options: Partial<TooltipOptions> = {}
  ): PopperInstance | null {
    const targetElement = this.getElement(element);
    if (!targetElement) {
      console.error('[ApolloPopper] Tooltip target element not found');
      return null;
    }

    const defaults: TooltipOptions = {
      placement: 'top',
      offset: 8,
      trigger: 'hover',
      delay: 200,
      hideDelay: 0,
      className: 'apollo-tooltip',
      arrow: true,
    };

    const config = { ...defaults, ...options };

    // Create tooltip element
    const tooltip = document.createElement('div');
    tooltip.className = config.className;
    tooltip.textContent = content;
    tooltip.style.display = 'none';
    tooltip.style.position = 'absolute';
    document.body.appendChild(tooltip);

    // Create arrow if needed
    if (config.arrow) {
      const arrow = document.createElement('div');
      arrow.className = 'apollo-tooltip-arrow';
      arrow.setAttribute('x-arrow', '');
      tooltip.appendChild(arrow);
    }

    // Create Popper instance
    const instance = this.create(targetElement, tooltip, {
      placement: config.placement,
      modifiers: {
        offset: {
          offset: config.offset,
        },
        arrow: config.arrow ? { element: '[x-arrow]' } : undefined,
      },
    });

    if (!instance) {
      tooltip.remove();
      return null;
    }

    // Setup event handlers
    let showTimeout: number | undefined;
    let hideTimeout: number | undefined;

    const show = (): void => {
      clearTimeout(hideTimeout);
      showTimeout = window.setTimeout(() => {
        tooltip.style.display = 'block';
        instance.update();
      }, config.delay);
    };

    const hide = (): void => {
      clearTimeout(showTimeout);
      hideTimeout = window.setTimeout(() => {
        tooltip.style.display = 'none';
      }, config.hideDelay);
    };

    if (config.trigger === 'hover') {
      targetElement.addEventListener('mouseenter', show);
      targetElement.addEventListener('mouseleave', hide);
      tooltip.addEventListener('mouseenter', show);
      tooltip.addEventListener('mouseleave', hide);
    } else if (config.trigger === 'click') {
      targetElement.addEventListener('click', () => {
        if (tooltip.style.display === 'none') {
          show();
        } else {
          hide();
        }
      });
    } else if (config.trigger === 'focus') {
      targetElement.addEventListener('focus', show);
      targetElement.addEventListener('blur', hide);
    }

    return instance;
  }

  /**
   * Creates a dropdown menu with predefined behavior
   */
  public createDropdown(
    trigger: HTMLElement | string,
    menu: HTMLElement | string,
    options: Partial<DropdownOptions> = {}
  ): PopperInstance | null {
    const triggerElement = this.getElement(trigger);
    const menuElement = this.getElement(menu);

    if (!triggerElement || !menuElement) {
      console.error('[ApolloPopper] Dropdown trigger or menu element not found');
      return null;
    }

    const defaults: DropdownOptions = {
      placement: 'bottom-start',
      offset: 4,
      trigger: 'click',
      closeOnClickOutside: true,
      className: 'apollo-dropdown-menu',
    };

    const config = { ...defaults, ...options };

    // Apply class to menu
    menuElement.classList.add(config.className);
    menuElement.style.display = 'none';

    // Create Popper instance
    const instance = this.create(triggerElement, menuElement, {
      placement: config.placement,
      modifiers: {
        offset: {
          offset: config.offset,
        },
        flip: {
          behavior: 'flip',
        },
      },
    });

    if (!instance) {
      return null;
    }

    // Setup event handlers
    const toggle = (): void => {
      const isHidden = menuElement.style.display === 'none';
      menuElement.style.display = isHidden ? 'block' : 'none';
      if (isHidden) {
        instance.update();
      }
    };

    const hide = (): void => {
      menuElement.style.display = 'none';
    };

    if (config.trigger === 'click') {
      triggerElement.addEventListener('click', (e) => {
        e.stopPropagation();
        toggle();
      });
    } else if (config.trigger === 'hover') {
      triggerElement.addEventListener('mouseenter', () => {
        menuElement.style.display = 'block';
        instance.update();
      });
      triggerElement.addEventListener('mouseleave', hide);
      menuElement.addEventListener('mouseleave', hide);
    }

    // Close on click outside
    if (config.closeOnClickOutside && config.trigger === 'click') {
      document.addEventListener('click', (e) => {
        if (
          !triggerElement.contains(e.target as Node) &&
          !menuElement.contains(e.target as Node)
        ) {
          hide();
        }
      });
    }

    return instance;
  }

  /**
   * Destroys a Popper instance
   */
  public destroy(instance: PopperInstance): void {
    if (this.instances.has(instance)) {
      instance.destroy();
      this.instances.delete(instance);
    }
  }

  /**
   * Destroys all managed Popper instances
   */
  public destroyAll(): void {
    this.instances.forEach((instance) => {
      instance.destroy();
    });
    this.instances.clear();
  }

  /**
   * Merges options objects deeply
   */
  private mergeOptions<T extends Record<string, any>>(
    defaults: T,
    overrides: Partial<T>
  ): T {
    const result = { ...defaults };

    for (const key in overrides) {
      if (Object.prototype.hasOwnProperty.call(overrides, key)) {
        const value = overrides[key];
        if (
          value !== null &&
          typeof value === 'object' &&
          !Array.isArray(value)
        ) {
          result[key] = this.mergeOptions(
            (result[key] || {}) as any,
            value as any
          );
        } else {
          result[key] = value as T[Extract<keyof T, string>];
        }
      }
    }

    return result;
  }
}

// ============================================================================
// Initialization
// ============================================================================

/**
 * Initialize Apollo Popper Manager
 */
const initializeApolloPopper = (): void => {
  const manager = new ApolloPopperManager();

  // Expose public API
  window.ApolloPopper = {
    create: manager.create.bind(manager),
    createTooltip: manager.createTooltip.bind(manager),
    createDropdown: manager.createDropdown.bind(manager),
    destroy: manager.destroy.bind(manager),
    destroyAll: manager.destroyAll.bind(manager),
    version: '3.0.0',
  };

  console.info('[ApolloPopper] Initialized successfully (v3.0.0)');
};

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initializeApolloPopper);
} else {
  initializeApolloPopper();
}

export {};