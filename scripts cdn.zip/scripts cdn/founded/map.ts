/**
 * Apollo Map Standardizer - Modern TypeScript Edition (2026)
 * 
 * Automatically enforces CARTO Positron Light tile style for all OpenStreetMap
 * Leaflet maps on the page, with support for retina displays and proper attribution.
 * 
 * @module ApolloMapStandard
 * @version 3.0.0
 * @license MIT
 */

// ============================================================================
// Type Definitions
// ============================================================================

/**
 * Extended Leaflet Map interface with internal properties
 */
interface LeafletMapExtended extends L.Map {
  _leaflet_map?: L.Map;
}

/**
 * HTML element with potential Leaflet map reference
 */
interface HTMLElementWithMap extends HTMLElement {
  _leaflet_map?: L.Map;
}

/**
 * Window interface with potential Leaflet map instances
 */
interface WindowWithMaps extends Window {
  ApolloMapa?: {
    map?: L.Map;
  };
  [key: string]: unknown;
}

/**
 * Public API interface
 */
interface ApolloMapStandardAPI {
  enforce: () => void;
  version: string;
}

// ============================================================================
// Global Window Extension
// ============================================================================

declare global {
  interface Window {
    ApolloMapStandard?: ApolloMapStandardAPI;
    ApolloMapa?: {
      map?: L.Map;
    };
    L?: typeof L;
  }
}

// ============================================================================
// Constants
// ============================================================================

const CONFIG = {
  /** Original OpenStreetMap tile domain */
  OSM_DOMAIN: 'tile.openstreetmap.org',
  
  /** CARTO Positron Light tile base URL */
  CARTO_BASE: 'basemaps.cartocdn.com/light_all',
  
  /** Combined attribution for OSM and CARTO */
  ATTRIBUTION: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
  
  /** Maximum zoom level for maps */
  MAX_ZOOM: 20,
  
  /** Interval for periodic enforcement checks (ms) */
  ENFORCEMENT_INTERVAL: 1000,
} as const;

// ============================================================================
// Implementation
// ============================================================================

/**
 * Immediately Invoked Function Expression (IIFE) for encapsulation
 */
((): void => {
  'use strict';

  // ============================================================================
  // Display Detection
  // ============================================================================

  /**
   * Detects if the current display is a retina/high-DPI screen
   * @returns True if retina display is detected
   */
  const isRetinaDisplay = (): boolean => {
    // Check Leaflet's built-in retina detection if available
    if (window.L?.Browser?.retina) {
      return true;
    }

    // Fallback to manual detection
    return (
      window.devicePixelRatio > 1 ||
      (window.matchMedia?.('(min-resolution: 144dpi)').matches ?? false)
    );
  };

  // ============================================================================
  // Tile Management
  // ============================================================================

  /**
   * Replaces OSM tile source with CARTO Positron Light tiles
   * @param img - Image element containing the tile
   */
  const replaceTileSource = (img: HTMLImageElement): void => {
    let src = img.src;

    // Only process OSM tiles
    if (!src.includes(CONFIG.OSM_DOMAIN)) {
      return;
    }

    // Replace domain
    src = src.replace(CONFIG.OSM_DOMAIN, CONFIG.CARTO_BASE);

    // Add retina suffix if needed
    if (isRetinaDisplay()) {
      src = src.replace(/\.png$/, '@2x.png');
    }

    img.src = src;
  };

  // ============================================================================
  // Attribution Management
  // ============================================================================

  /**
   * Updates map attribution to comply with CARTO licensing requirements
   * @param container - Leaflet container element
   */
  const updateAttribution = (container: HTMLElement): void => {
    const attributionControl = container.querySelector<HTMLElement>(
      '.leaflet-control-attribution'
    );

    if (attributionControl) {
      attributionControl.innerHTML = CONFIG.ATTRIBUTION;
    }
  };

  // ============================================================================
  // Map Configuration
  // ============================================================================

  /**
   * Attempts to find the Leaflet map instance for a container
   * @param container - Map container element
   * @returns Leaflet map instance or null
   */
  const findMapInstance = (container: HTMLElement): L.Map | null => {
    const win = window as WindowWithMaps;

    // Check global ApolloMapa reference
    if (win.ApolloMapa?.map instanceof L.Map) {
      return win.ApolloMapa.map;
    }

    // Check container's internal reference
    const containerWithMap = container as HTMLElementWithMap;
    if (containerWithMap._leaflet_map) {
      return containerWithMap._leaflet_map;
    }

    // Check window object by map ID
    const mapId = container.getAttribute('id');
    if (mapId && win[mapId] instanceof L.Map) {
      return win[mapId] as L.Map;
    }

    return null;
  };

  /**
   * Updates map options to set proper max zoom level
   * @param container - Map container element
   */
  const updateMapOptions = (container: HTMLElement): void => {
    const map = findMapInstance(container);

    if (map) {
      map.options.maxZoom = CONFIG.MAX_ZOOM;
      map.setMaxZoom(CONFIG.MAX_ZOOM);
    }
  };

  // ============================================================================
  // Mutation Observer
  // ============================================================================

  /**
   * MutationObserver to watch for dynamically added tiles
   */
  const tileObserver = new MutationObserver((mutations: MutationRecord[]) => {
    mutations.forEach((mutation) => {
      if (mutation.type !== 'childList') {
        return;
      }

      mutation.addedNodes.forEach((node) => {
        if (
          node instanceof HTMLImageElement &&
          node.classList.contains('leaflet-tile')
        ) {
          replaceTileSource(node);
        }
      });
    });
  });

  // ============================================================================
  // Enforcement
  // ============================================================================

  /**
   * Enforces CARTO Positron Light tiles on all Leaflet maps
   * This is the main function that processes all maps on the page
   */
  const enforceMapStandard = (): void => {
    const tilePanes = document.querySelectorAll<HTMLElement>('.leaflet-tile-pane');

    tilePanes.forEach((pane) => {
      const mapContainer = pane.closest<HTMLElement>('.leaflet-container');
      if (!mapContainer) {
        return;
      }

      // Process existing tiles
      const tiles = pane.querySelectorAll<HTMLImageElement>('img.leaflet-tile');
      tiles.forEach(replaceTileSource);

      // Update attribution
      updateAttribution(mapContainer);

      // Update map configuration
      updateMapOptions(mapContainer);

      // Observe future tile additions
      tileObserver.observe(pane, {
        childList: true,
        subtree: true,
      });
    });
  };

  // ============================================================================
  // Initialization
  // ============================================================================

  /**
   * Initialize the map standardizer
   */
  const initialize = (): void => {
    // Initial enforcement
    enforceMapStandard();

    // Periodic enforcement for dynamically created maps
    setInterval(enforceMapStandard, CONFIG.ENFORCEMENT_INTERVAL);

    console.info(
      '[ApolloMapStandard] Loaded: All OSM maps forced to CARTO Positron Light visuals (v3.0.0 - 2026 edition)'
    );
  };

  // ============================================================================
  // Bootstrap
  // ============================================================================

  // Initialize after DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialize);
  } else {
    initialize();
  }

  // ============================================================================
  // Public API
  // ============================================================================

  /**
   * Expose public API to window object
   */
  window.ApolloMapStandard = {
    enforce: enforceMapStandard,
    version: '3.0.0',
  };
})();

export {};