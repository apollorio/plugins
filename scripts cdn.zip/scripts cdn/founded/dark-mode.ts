/**
 * Apollo Dark Mode Runtime - Modern TypeScript Edition (2026)
 * 
 * A comprehensive, type-safe dark mode management system with localStorage persistence,
 * system preference detection, and custom event emission.
 * 
 * @module ApolloDarkMode
 * @version 3.0.0
 * @license MIT
 */

// ============================================================================
// Type Definitions
// ============================================================================

/**
 * Configuration options for the dark mode system
 */
interface DarkModeConfig {
  /** ID of the toggle button element */
  toggleId?: string;
  /** CSS class to apply when dark mode is active */
  darkClass?: string;
  /** localStorage key for theme persistence */
  storageKey?: string;
  /** Whether to respect system color scheme preferences */
  respectSystem?: boolean;
}

/**
 * Theme state values
 */
type ThemeState = 'dark' | 'light' | null;

/**
 * Custom event detail for dark mode changes
 */
interface DarkModeEventDetail {
  isDark: boolean;
}

/**
 * Public API interface
 */
interface ApolloDarkModeAPI {
  toggle: () => void;
  enable: () => void;
  disable: () => void;
  isDark: () => boolean;
  version: string;
}

// ============================================================================
// Global Window Extension
// ============================================================================

declare global {
  interface Window {
    apolloDarkMode?: ApolloDarkModeAPI;
    apolloDarkModeConfig?: DarkModeConfig;
    __apolloDarkModeRuntime?: number;
  }
}

// ============================================================================
// Implementation
// ============================================================================

/**
 * Immediately Invoked Function Expression (IIFE) to prevent multiple initializations
 */
((): void => {
  // Prevent duplicate initialization
  if (window.__apolloDarkModeRuntime) {
    return;
  }
  window.__apolloDarkModeRuntime = 1;

  // Configuration with defaults
  const config: Required<DarkModeConfig> = {
    toggleId: window.apolloDarkModeConfig?.toggleId ?? 'darkModeToggle',
    darkClass: window.apolloDarkModeConfig?.darkClass ?? 'dark-mode',
    storageKey: window.apolloDarkModeConfig?.storageKey ?? 'apollo-theme',
    respectSystem: window.apolloDarkModeConfig?.respectSystem ?? true,
  };

  // DOM element references
  const doc = document;
  const html = doc.documentElement;
  const body = doc.body;

  // ============================================================================
  // Storage Management
  // ============================================================================

  /**
   * Retrieves the stored theme preference from localStorage
   * @returns The stored theme state or null if not found/error
   */
  const getStoredTheme = (): ThemeState => {
    try {
      const stored = localStorage.getItem(config.storageKey);
      return stored as ThemeState;
    } catch (error) {
      console.warn('[ApolloDarkMode] localStorage access failed:', error);
      return null;
    }
  };

  /**
   * Persists theme preference to localStorage
   * @param value - Theme state to store
   */
  const setStoredTheme = (value: 'dark' | 'light'): void => {
    try {
      localStorage.setItem(config.storageKey, value);
    } catch (error) {
      console.warn('[ApolloDarkMode] localStorage write failed:', error);
    }
  };

  // ============================================================================
  // State Management
  // ============================================================================

  /**
   * Checks if dark mode is currently active
   * @returns True if dark mode class is present
   */
  const isDarkMode = (): boolean => {
    return body?.classList.contains(config.darkClass) ?? false;
  };

  /**
   * Emits a custom event when dark mode state changes
   * @param isDark - Current dark mode state
   */
  const emitDarkModeEvent = (isDark: boolean): void => {
    const event = new CustomEvent<DarkModeEventDetail>('apollo:darkmode', {
      detail: { isDark },
      bubbles: true,
      cancelable: false,
    });
    window.dispatchEvent(event);
  };

  /**
   * Enables dark mode by adding the dark class to body and html elements
   */
  const enableDarkMode = (): void => {
    if (!body) return;

    body.classList.add(config.darkClass);
    html?.classList.add(config.darkClass);
    setStoredTheme('dark');
    emitDarkModeEvent(true);
  };

  /**
   * Disables dark mode by removing the dark class from body and html elements
   */
  const disableDarkMode = (): void => {
    if (!body) return;

    body.classList.remove(config.darkClass);
    html?.classList.remove(config.darkClass);
    setStoredTheme('light');
    emitDarkModeEvent(false);
  };

  /**
   * Toggles between dark and light mode
   */
  const toggleDarkMode = (): void => {
    if (isDarkMode()) {
      disableDarkMode();
    } else {
      enableDarkMode();
    }
  };

  // ============================================================================
  // System Preference Detection
  // ============================================================================

  /**
   * Checks if the system prefers dark color scheme
   * @returns True if system prefers dark mode and respectSystem is enabled
   */
  const systemPrefersDark = (): boolean => {
    if (!config.respectSystem || !window.matchMedia) {
      return false;
    }
    return window.matchMedia('(prefers-color-scheme: dark)').matches;
  };

  // ============================================================================
  // Event Handlers
  // ============================================================================

  /**
   * Handles system color scheme preference changes
   * @param event - MediaQueryList change event
   */
  const handleSystemPreferenceChange = (event: MediaQueryListEvent): void => {
    // Only apply system preference if user hasn't set an explicit preference
    if (!getStoredTheme()) {
      if (event.matches) {
        enableDarkMode();
      } else {
        disableDarkMode();
      }
    }
  };

  /**
   * Handles click events on toggle buttons
   * @param event - Mouse click event
   */
  const handleToggleClick = (event: MouseEvent): void => {
    event.preventDefault();
    toggleDarkMode();
  };

  // ============================================================================
  // Initialization
  // ============================================================================

  /**
   * Applies initial theme immediately (before DOM is fully loaded)
   * This prevents flash of unstyled content (FOUC)
   */
  const applyInitialTheme = (): void => {
    const storedTheme = getStoredTheme();

    if (storedTheme === 'dark' && html) {
      html.classList.add(config.darkClass);
    }
  };

  /**
   * Initializes the dark mode system after DOM is ready
   */
  const initialize = (): void => {
    const storedTheme = getStoredTheme();

    // Apply stored preference or system preference
    if (storedTheme === 'dark') {
      enableDarkMode();
    } else if (storedTheme === 'light') {
      disableDarkMode();
    } else if (systemPrefersDark()) {
      enableDarkMode();
    }

    // Attach event listeners to toggle button
    const toggleButton = doc.getElementById(config.toggleId);
    toggleButton?.addEventListener('click', handleToggleClick);

    // Attach event listeners to all elements with data-toggle-dark attribute
    const toggleElements = doc.querySelectorAll<HTMLElement>('[data-toggle-dark]');
    toggleElements.forEach((element) => {
      element.addEventListener('click', handleToggleClick);
    });

    // Watch for system preference changes
    if (config.respectSystem && window.matchMedia) {
      const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');

      // Use modern addEventListener if available, fallback to addListener
      if (mediaQuery.addEventListener) {
        mediaQuery.addEventListener('change', handleSystemPreferenceChange);
      } else if ('addListener' in mediaQuery) {
        // @ts-expect-error - Fallback for older browsers
        mediaQuery.addListener(handleSystemPreferenceChange);
      }
    }

    console.info('[ApolloDarkMode] Initialized successfully (v3.0.0)');
  };

  // ============================================================================
  // Bootstrap
  // ============================================================================

  // Apply initial theme immediately to prevent FOUC
  applyInitialTheme();

  // Initialize after DOM is ready
  if (doc.readyState === 'loading') {
    doc.addEventListener('DOMContentLoaded', initialize);
  } else {
    initialize();
  }

  // ============================================================================
  // Public API
  // ============================================================================

  /**
   * Expose public API to window object
   */
  window.apolloDarkMode = {
    toggle: toggleDarkMode,
    enable: enableDarkMode,
    disable: disableDarkMode,
    isDark: isDarkMode,
    version: '3.0.0',
  };
})();

export {};