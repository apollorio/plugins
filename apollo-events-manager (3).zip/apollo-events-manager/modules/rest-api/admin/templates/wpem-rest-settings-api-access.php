<?php 
$rest_api_keys = new WPEM_Rest_API_Keys();
$rest_api_keys::page_output();
?>