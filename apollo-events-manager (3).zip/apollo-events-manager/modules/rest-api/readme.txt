=== WP Event Manager - REST API ===

Contributors: wpeventmanager,ashokdudhat,krinay
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=55FRYATTFLA5N
Tags: event manager, Event, events, event manager api , listings
Requires at least: 6.5.1
Tested up to: 6.8
Stable tag: 1.2.0

Requires PHP: 8.0.0
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

WP Event Manager Rest API


== Description ==

WP Event Manager Rest API

* [Demo](https://demo.wp-eventmanager.com/)
* [Add-ons](http://www.wp-eventmanager.com/plugins/)
* [Documentation](http://www.wp-eventmanager.com/documentation/)

[youtube https://www.youtube.com/watch?v=CPK0P7ToRgM]


= Documentation =

Documentation for the core plugin and add-ons can be found [on the docs site here](https://wp-eventmanager.com/knowledge-base/). Please take a look before requesting support because it covers all frequently asked questions!


= Be a contributor =
If you want to contribute, go to our [WP Event Manager Rest API GitHub Repository](https://github.com/wpeventmanager/wpem-rest-api/) and see where you can help.

You can also add a new language via [translate.wordpress.org](https://translate.wordpress.org/projects/wp-plugins/wpem-rest-api). We've built a short guide explaining [how to translate and localize the plugin](https://www.wp-eventmanager.com/documentation/translating-wp-event-manager/).

Thanks to all of our contributors.

= Documentation and Support =
- For documentation and tutorials go to our [Documentation](https://wp-eventmanager.com/knowledge-base/).
- If you have any more questions, visit our support on the [Plugin's Forum](https://wordpress.org/support/plugin/wpem-rest-api).
- If you want help with a customisation, you can contact any one for the [Listed Certified Developers](https://www.wp-eventmanager.com/hire-certified-wp-event-manager-developers/?utm_source=wp-repo&utm_medium=link&utm_campaign=readme).
- If you need help with one of our add-ons, [please contact here](https://www.wp-eventmanager.com/get-support/?utm_source=wp-repo&utm_medium=link&utm_campaign=readme).
- For more information about features, FAQs and documentation, check out our website at [WP Event Manager](https://www.wp-eventmanager.com/?utm_source=wp-repo&utm_medium=link&utm_campaign=readme).


= Connect With US =
To stay in touch and get latest update about WP Event Manager's further releases and features, you can connect with us via:
- [Facebook](https://www.facebook.com/wpeventmanager/)
- [Twitter](https://twitter.com/wp_eventmanager)
- [Google Plus](https://plus.google.com/u/0/b/107105224603939407328/107105224603939407328)
- [Linkedin](https://www.linkedin.com/company/wp-event-manager)
- [Pinterest](https://www.pinterest.com/wpeventmanager/)
- [Youtube](https://www.youtube.com/channel/UCnfYxg-fegS_n9MaPNU61bg).


== Installation ==


= Automatic installation =

Automatic installation is the easiest option as WordPress handles the file transfers itself and you don't even need to leave your web browser. To do an automatic install, log in to your WordPress admin panel, navigate to the Plugins menu and click Add New.

In the search field type "WP Event Manager" and click Search Plugins. Once you've found the plugin you can view details about it such as the the point release, rating and description. Most importantly of course, you can install it by clicking _Install Now_.


= Manual installation =

The manual installation method involves downloading the plugin and uploading it to your web server via your favorite FTP application.

* Download the plugin file to your computer and unzip it

* Using an FTP program, or your hosting control panel, upload the unzipped plugin folder to your WordPress installation's `wp-content/plugins/` directory.

* Activate the plugin from the Plugins menu within the WordPress admin.


= Getting started =

Once installed:

**Note when using shortcodes**, if the content looks blown up/spaced out/poorly styled, edit your page and above the visual editor click on the 'text' tab. Then remove any 'pre' or 'code' tags wrapping your shortcode.


== Frequently Asked Questions ==

= How do I setup WP Event Manager? =

View the getting [installation](http://www.wp-eventmanager.com/plugins-documentation/wp-event-manager/installation/) and [setup](http://www.wp-eventmanager.com/plugins-documentation/wp-event-manager/setting-up-wp-event-manager/) guide for advice getting started with the plugin. In most cases it's just a case of adding some shortcodes to your pages!


= Can I use WP Event Manager without frontend event submission? =

Yes! If you don't setup the [submit_event_form] shortcode, you can just post from the admin backend.


= How can I customize the event submission form? =

There are three ways to customize the fields in WP Event Manager;


1. For simple text changes, using a localisation file or a plugin such as [Say What](https://wordpress.org/plugins/say-what/).

2. For field changes, or adding new fields, using functions/filters inside your theme's functions.php file: [Read more](http://www.wp-eventmanager.com/plugins-documentation/wp-event-manager/editing-event-submission-form-fields/).

3. Use a 3rd party plugin which has a UI for field editing.


If you'd like to learn about WordPress filters, here is a great place to start: [Read more](https://pippinsplugins.com/a-quick-introduction-to-using-filters/).


= How can I be notified of new events via email? =

If you wish to be notified of new postings on your site you can use a plugin such as [Post Status Notifier](http://wordpress.org/plugins/post-status-notifier-lite/).


== Screenshots ==


== Changelog ==

= 1.2.0 [ 10th September 2025 ] =

Fixed : Validation while app key generate
Fixed : App Branding API should be accessible to Attendee
Fixed : Issue in get registered event list for selected user
Fixed : Send name-badge addon details in ecosystem API
Fixed : Add user friendly words and messages
Fixed : Add message-notification flag in get-conversation-list & get-messages API
Fixed : Non dj user or volunteer login with app not working
Fixed : Add search by Username in Rest API
Fixed : Meeting create email template design same like web
Fixed : Various Bug Fixes and Code Improvements

= 1.1.2 [ 27th August 2025 ] =

Fixed : Not able to create rest API access key
Fixed : Taxonomy API Not working
Fixed : When Passing empty profile photo then set to default User Image
Fixed : Access to API always open to everyone everytime
Fixed : Add API for matchmaking setting GET and POST
Fixed : Add API related to visibility setting
Fixed : Add API for meeting setting
Fixed : Password change then user will auto logout from mobile application
Fixed : Various bug fixes and code Improvements

= 1.1.1 [ 25th August 2025 ] =

Fixed : Warnings of undefined variables

= 1.1.1 [ 25th August 2025 ] =

Fixed : Warnings of undefined variables

= 1.1.0 [ 19th August 2025 ] =

Fixed : Change the Plugin name
Fixed : After password change the user will auto logout from mobile app
Fixed : Without Active license some section of the app will not work
Added : Match making functionality

= 1.0.10 [ 09th May 2025 ] =

Fixed: All events are shown even from other djs

= 1.0.9 [ 02nd May 2025 ] =

Fixed: API response time is improved to make APIs faster
Fixed: API requests are now protected with authorization
Fixed: The data loading time in the attendee section became faster
Fixed: The manual check-in process of attendees became faster
Fixed: Initiated multiple bug fixes and code improvements

= 1.0.8 [ 27th March 2025 ] =

Fixed : Password with some special character, user not able to loggedin in app.

= 1.0.7 [ 12th March 2025 ] =

Fixed : Centralize repsponse of Rest Api.
Fixed : Without active license, APP will not work and show message that renew your license.
Fixed : Checkin restriction based on app loggedin user and web settings.
Added : Create API for login with username and password instead of app key.
Added : Checkin restriction API added.

= 1.0.6 [ 26th September 2024 ] =

Fixed : Change light mode to dark mode is not save.
Fixed : Generates multiple API keys.
Fixed : Deprecated code error is fixed.

= 1.0.5 [ 9th Feb 2023 ] =

Fixed : Remove a message from the App branding page.
Added : API key expiry status is added.

= 1.0.4 [ 17th Oct 2023 ] =

Fixed : Description is added for REST API addon.
Fixed : Repeated Ajax requests sending while selecting a color issue is fixed.
Fixed : Display the save message while saving App Branding.
Fixed : Show the notice in proper alignment.
Added : A copied key button is added on the key generate page.
Added : Application name feature added to the add-on.

= 1.0.3 [ 22nd Dec 2022 ] =

Fixed - Event Ticket scaning issue with mobile app.
Fixed - Order tab option not working in mobile app.
Fixed - Event dj user permission issue.
Fixed - dj add note feature not working correctly.
Fixed - Ticket sales report visibility issue. 
Fixed - Removed licence key for Rest API addon.

= 1.0.2 [ May 18th, 2022 ] =

Fixed - Ecosystem Controller file.

= 1.0.1 [ May 17th, 2022 ] =

Fixed - Past events search.
Fixed - Message and status code improvements.
Fixed - Data improvements.


= 1.0.0 [ 9th Apr 2021 ] =

* Inital release.
