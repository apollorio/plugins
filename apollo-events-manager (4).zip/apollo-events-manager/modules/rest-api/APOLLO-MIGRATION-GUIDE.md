# 🔄 APOLLO EVENTS MANAGER - REST API MIGRATION

**Status:** ⚠️ MIGRAÇÃO EM PROGRESSO  
**Data:** 2025-11-04  
**Versão Alvo:** 2.0.0

---

## ✅ ALTERAÇÕES APLICADAS

### 1. Header do Plugin (wpem-rest-api.php)
- ✅ Nome: "Apollo Events Manager - REST API"
- ✅ URI: https://apollo.rio.br/
- ✅ Autor: Apollo::Rio
- ✅ Text Domain: apollo-rest-api
- ✅ Versão: 2.0.0
- ✅ Requires: Apollo Events Manager 2.0.0

### 2. Verificação de Dependência (linhas 38-47)
- ✅ Alterado de `wp-event-manager/wp-event-manager.php`
- ✅ Para: `apollo-events-manager/apollo-events-manager.php`
- ✅ Admin notice atualizado

### 3. Inicialização do Plugin (linha 365)
- ✅ Alterado `is_plugin_active('wp-event-manager/wp-event-manager.php')`
- ✅ Para: `is_plugin_active('apollo-events-manager/apollo-events-manager.php')`

---

## ⚠️ ALTERAÇÕES PENDENTES (MANUAL)

### Linha 369-385: Função de Verificação

**LOCALIZAR:**
```php
/**
| * Check if WP Event Manager is not active then show notice at admin
| * @since 1.0.0
| */
function wpem_rest_api_pre_check_before_installing_event_rest_api() {
    /*
    * Check weather WP Event Manager is installed or not
    */
    if( !in_array( 'wp-event-manager/wp-event-manager.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
            global $pagenow;
        if($pagenow == 'plugins.php' ) {
            echo '<div id="error" class="error notice is-dismissible"><p>';
            echo __( 'WP Event Manager is require to use WP Event Manager Rest API ', 'wpem-rest-api' );
            echo '</p></div>';
        }
        return false;
    }
```

**SUBSTITUIR POR:**
```php
/**
| * Check if Apollo Events Manager is not active then show notice at admin
| * @since 1.0.0
| */
function wpem_rest_api_pre_check_before_installing_event_rest_api() {
    /*
    * Check whether Apollo Events Manager is installed or not
    */
    if( !in_array( 'apollo-events-manager/apollo-events-manager.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
            global $pagenow;
        if($pagenow == 'plugins.php' ) {
            echo '<div id="error" class="error notice is-dismissible"><p>';
            echo __( 'Apollo Events Manager is required to use Apollo Events Manager REST API ', 'apollo-rest-api' );
            echo '</p></div>';
        }
        return false;
    }
```

---

## 🔍 OUTROS PLUGINS - STATUS DE COMPATIBILIDADE

### ✅ wpem-bookmarks
**Status:** JÁ COMPATÍVEL COM APOLLO

```php
// wpem-bookmarks.php linha 36
add_filter('favorites/post_types', function($types){
  return ['event_listing','dj'];  // ✅ USA CPTs do Apollo
});

// includes/wpem-hooks.php linha 4
add_action('single_event_listing_end', function(){
  // ✅ Hook compatível com Apollo
});
```

**Conclusão:** Não precisa de alterações, já usa os CPTs corretos.

---

### ✅ apollo-rio
**Status:** INDEPENDENTE

**Função:** PWA templates (não depende de eventos)  
**Conclusão:** Sem alterações necessárias.

---

## 📋 CHECKLIST DE MIGRAÇÃO COMPLETA

### Arquivo: wpem-rest-api.php
- [x] Header atualizado (linhas 1-20)
- [x] Verificação de dependência no construtor (linhas 38-47)
- [x] `is_plugin_active()` check (linha 365)
- [ ] Função de verificação (linhas 369-385) ⚠️ MANUAL

### Verificar em Todos os Arquivos
- [ ] Buscar/substituir `wp-event-manager` → `apollo-events-manager`
- [ ] Buscar/substituir text domain `wpem-rest-api` → `apollo-rest-api`
- [ ] Atualizar mensagens de erro/admin notices
- [ ] Atualizar comentários de código

---

## 🔧 COMANDOS DE BUSCA GLOBAL

```bash
# Encontrar todas as referências a WP Event Manager
grep -r "wp-event-manager" wpem-rest-api/

# Encontrar text domain antigo
grep -r "wpem-rest-api" wpem-rest-api/ | grep "__\|_e\|esc_"

# Encontrar verificações de plugin ativo
grep -r "is_plugin_active\|in_array.*wp-event-manager" wpem-rest-api/
```

---

## 🎯 PRÓXIMOS PASSOS

1. **Aplicar substituição manual** na linha 369-385
2. **Busca global** em todos os arquivos do wpem-rest-api:
   - `includes/*.php`
   - `admin/*.php`
   - `admin/templates/*.php`
3. **Testar endpoints REST API**
4. **Atualizar readme.txt**
5. **Commit com mensagem:**
   ```bash
   git commit -m "Migrate REST API from WP Event Manager to Apollo Events Manager 2.0"
   ```

---

## ⚙️ ENDPOINTS QUE PRECISAM SER TESTADOS

```
GET  /wp-json/wpem/v1/events
GET  /wp-json/wpem/v1/events/{id}
POST /wp-json/wpem/v1/events
GET  /wp-json/wpem/v1/organizers
GET  /wp-json/wpem/v1/venues
GET  /wp-json/wpem/v1/categories
```

**Verificar:** Todos ainda funcionam com Apollo Events Manager CPTs.

---

## 📊 RESUMO

| Item | Status |
|------|--------|
| **Header do Plugin** | ✅ Atualizado |
| **Dependency Check (construtor)** | ✅ Atualizado |
| **is_plugin_active() check** | ✅ Atualizado |
| **Função de verificação** | ⚠️ Pendente (manual) |
| **wpem-bookmarks** | ✅ Já compatível |
| **apollo-rio** | ✅ Independente |
| **Busca global em includes/** | ⏳ Aguardando |
| **Busca global em admin/** | ⏳ Aguardando |
| **Testes de API** | ⏳ Aguardando |

---

**Última Atualização:** 2025-11-04  
**Aplicado por:** AI Senior WordPress Engineer  
**Review Necessário:** Substituição manual linha 369-385

