<?php 
$rest_app_branding = new WPEM_Rest_APP_Branding();
$rest_app_branding::page_output();
?>