<?php
/* Canvas template for /eventos - Loads complete portal template */
defined('ABSPATH') || exit;

// Use the complete portal discover template
include APOLLO_WPEM_PATH . 'templates/portal-discover.php';